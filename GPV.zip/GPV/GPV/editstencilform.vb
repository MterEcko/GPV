﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Imports System.IO

Imports GPV.Db

Public Class editstencilform
    Dim bdconexion As New Db()
    Private Sub hideForm()
        PanelF.Visible = False
    End Sub
    Private Sub showForm()

    End Sub
    Private PFormu As Form = Nothing
    Private Sub openPanel(PanelForm As Form)
        If PFormu IsNot Nothing Then PFormu.Close()
        PFormu = PanelForm
        PanelForm.TopLevel = False
        PanelForm.FormBorderStyle = FormBorderStyle.None
        PanelForm.Dock = DockStyle.Fill
        PanelF.Controls.Add(PanelForm)
        PanelF.Tag = PanelForm
        PanelForm.BringToFront()
        PanelForm.Show()
    End Sub

    Private Sub Home_Click(sender As Object, e As EventArgs) Handles Home.Click
        openPanel(New dashboardPanel)
    End Sub

    Private Sub ToolingBtn_Click(sender As Object, e As EventArgs) Handles toolingBtn.Click
        openPanel(New Tooling)
    End Sub

    Private Sub StencilToolBtn_Click(sender As Object, e As EventArgs) Handles StencilTool1Btn.Click, StencilToolBtn.Click
        openPanel(New Stencil)
    End Sub

    Private Sub EditStencilBtn_Click(sender As Object, e As EventArgs) Handles EditStencilBtn.Click
        openPanel(New editstencilform)
    End Sub
    Private Sub txtStencilName_Enter(sender As Object, e As EventArgs)
        'If txtStencilNameEdit.Text = "Stencil Name" Then
        'txtStencilNameEdit.Text = ""
        'txtStencilNameEdit.ForeColor = Color.ForestGreen
        'End If
    End Sub

    Private Sub txtStencilName_Leave(sender As Object, e As EventArgs)
        'If txtStencilNameEdit.Text = "" Then
        'txtStencilNameEdit.Text = "Stencil Name"
        'txtStencilNameEdit.ForeColor = Color.ForestGreen
        'End If
    End Sub
    Private Sub txtNumberPartPCB_Enter(sender As Object, e As EventArgs)
        If txtNumberPartPCBEdit.Text = "Number Part of PCB" Then
            txtNumberPartPCBEdit.Text = ""
            txtNumberPartPCBEdit.ForeColor = Color.ForestGreen
        End If
    End Sub
    Private Sub txtNumberPartPCB_Leave(sender As Object, e As EventArgs)
        If txtNumberPartPCBEdit.Text = "" Then
            txtNumberPartPCBEdit.Text = "Number Part of PCB"
            txtNumberPartPCBEdit.ForeColor = Color.ForestGreen
        End If
    End Sub
    Private Sub txtXPCB_Enter(sender As Object, e As EventArgs)
        If txtXPCBEdit.Text = "X Lengh" Then
            txtXPCBEdit.Text = ""
            txtXPCBEdit.ForeColor = Color.ForestGreen
        End If
    End Sub
    Private Sub txtXPCB_Leave(sender As Object, e As EventArgs)
        If txtXPCBEdit.Text = "" Then
            txtXPCBEdit.Text = "X Lengh"
            txtXPCBEdit.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub txtYPCB_Enter(sender As Object, e As EventArgs)
        If txtYPCBEdit.Text = "Y Width" Then
            txtYPCBEdit.Text = ""
            txtYPCBEdit.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub txtYPCB_Leave(sender As Object, e As EventArgs)
        If txtYPCBEdit.Text = "" Then
            txtYPCBEdit.Text = "Y Width"
            txtYPCBEdit.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub txtRevStencil_Enter(sender As Object, e As EventArgs)
        If txtRevStencilEdit.Text = "Revision" Then
            txtRevStencilEdit.Text = ""
            txtRevStencilEdit.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub txtRevStencil_Leave(sender As Object, e As EventArgs)
        If txtRevStencilEdit.Text = "" Then
            txtRevStencilEdit.Text = "Revision"
            txtRevStencilEdit.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub txtJobStencil_Enter(sender As Object, e As EventArgs)
        If txtJobStencilEdit.Text = "Job" Then
            txtJobStencilEdit.Text = ""
            txtJobStencilEdit.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub txtJobStencil_Leave(sender As Object, e As EventArgs)
        If txtJobStencilEdit.Text = "" Then
            txtJobStencilEdit.Text = "Job"
            txtJobStencilEdit.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub txtCommentsStencil_Enter(sender As Object, e As EventArgs)
        If txtCommentsStencilEdit.Text = "Ingrese comentarios" Then
            txtCommentsStencilEdit.Text = ""
            txtCommentsStencilEdit.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub txtCommentsStencil_Leave(sender As Object, e As EventArgs)
        If txtCommentsStencilEdit.Text = "" Then
            txtCommentsStencilEdit.Text = "Ingrese comentarios"
            txtCommentsStencilEdit.ForeColor = Color.ForestGreen
        End If
    End Sub


    Private Sub editstencilform_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        bdconexion.Conectar()
        'ComboBoxProyectosList.DataSource = bdconexion.ConsultaComboBoxProyectos
        If (DataGridStencil.IdStencil <> "") Then
            'txtEnsambleEdit.Text = DataGridStencil.IdStencil

            txtStencilNameEdit.Text = DataGridStencil.StencilNameEdit
            txtEnsambleEdit.Text = DataGridStencil.EnsambleEdit
            txtNumberPartPCBEdit.Text = DataGridStencil.NumberPartStencilEdit
            txtXPCBEdit.Text = DataGridStencil.XEdit
            txtYPCBEdit.Text = DataGridStencil.YEdit
            txtRevStencilEdit.Text = DataGridStencil.RevisionEdit
            txtJobStencilEdit.Text = DataGridStencil.JobEdit
            txtLocalidadStencilEdit.Text = DataGridStencil.LocalidadEdit
            txtNum1TensionEdit.Text = DataGridStencil.Num1TensionEdit
            txtNum2TensionEdit.Text = DataGridStencil.Num2TensionEdit
            txtNum3TensionEdit.Text = DataGridStencil.Num3TensionEdit
            txtNum4TensionEdit.Text = DataGridStencil.Num4TensionEdit
            txtNum5TensionEdit.Text = DataGridStencil.Num5TensionEdit
            txtCommentsStencilEdit.Text = DataGridStencil.ComentariosStencilEdit
            'ComboBoxProyectosList.DataSource = bdconexion.ConsultaComboBoxProyectos()
            'ComboBoxProyectosList.DataSource = DataGridStencil.ListProyectos
            'ComboBoxProyectosList.DataSource = DataGridStencil.ListProyectos
            ComboBoxProyectosList.DataSource = bdconexion.Proyectos()
            ComboBoxProyectosList.DisplayMember = ""
            ComboBoxProyectosList.ValueMember = ""

            'ComboBoxProyect.DisplayMember = "Proyecto"
            'ComboBoxProyect.ValueMember = "ID"

            '
            'txtNumberPartPCBEdit.Text = Dr("Proyecto").ToString()

            'proyectName.SelectedValue = Dr("Proyect")
            'DateMakeJob.Norecuerdo = Dr("DateManufacture")
            'DateManufactory.Norecoruedo = Dr("DataRun")

            'provedorNameEdit.Text = Dr("Provedor").ToString()

            'Dim Proyecto = Dr("Proyect").ToString()
            'txtNumberPartPCBEdit.Text = Proyecto
            'ComboBoxProyect.DataSource = bdconexion.Proyectos()
            'ComboBoxProyectos.

            'Dim ListaProyectos = DataGridStencil.ListProyectos
            ' While (ListaProyectos)
            'ComboBoxProyect.Items.Add(ListaProyectos.GetS)
            ' End While
            'ComboBoxProyect.Items.Add(bdconexion.Proyectos())
            'MsgBox(ListaProyectos)


        End If



    End Sub

    Private Sub ComboBoxProyect_GotFocus(sender As Object, e As EventArgs) Handles ComboBoxProyectosList.GotFocus
        'LlenarComboProyectos()
        'ComboBoxProyect.DataSource = bdconexion.Proyectos()
    End Sub

    Private Sub ComboBoxProyect_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBoxProyectosList.SelectedIndexChanged

    End Sub

    Private Sub txtStencilNameEdit_TextChanged(sender As Object, e As EventArgs) Handles txtStencilNameEdit.TextChanged

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub
End Class