﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Tooling
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PanelF = New System.Windows.Forms.Panel()
        Me.Home = New System.Windows.Forms.Button()
        Me.toolingBtn = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.framesDishBtn = New System.Windows.Forms.Button()
        Me.conformailDishBtn = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.routerDishBtn = New System.Windows.Forms.Button()
        Me.PalletsRegularBtn = New System.Windows.Forms.Button()
        Me.PalletsSelectiveBtn = New System.Windows.Forms.Button()
        Me.SquegueBtn = New System.Windows.Forms.Button()
        Me.FramesPalletsBtn = New System.Windows.Forms.Button()
        Me.StencilBtn = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Home1Btn = New System.Windows.Forms.Button()
        Me.User = New System.Windows.Forms.Label()
        Me.viewDetailsBtnForm = New System.Windows.Forms.Button()
        Me.PanelF.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelF
        '
        Me.PanelF.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelF.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.PanelF.Controls.Add(Me.Home)
        Me.PanelF.Controls.Add(Me.toolingBtn)
        Me.PanelF.Controls.Add(Me.Panel1)
        Me.PanelF.Controls.Add(Me.viewDetailsBtnForm)
        Me.PanelF.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PanelF.ForeColor = System.Drawing.Color.ForestGreen
        Me.PanelF.Location = New System.Drawing.Point(0, 0)
        Me.PanelF.Name = "PanelF"
        Me.PanelF.Size = New System.Drawing.Size(683, 574)
        Me.PanelF.TabIndex = 39
        '
        'Home
        '
        Me.Home.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.Home.FlatAppearance.BorderSize = 3
        Me.Home.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Home.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.Home.ForeColor = System.Drawing.Color.ForestGreen
        Me.Home.Location = New System.Drawing.Point(13, 12)
        Me.Home.Name = "Home"
        Me.Home.Size = New System.Drawing.Size(103, 38)
        Me.Home.TabIndex = 115
        Me.Home.Text = "Home"
        Me.Home.UseVisualStyleBackColor = False
        '
        'toolingBtn
        '
        Me.toolingBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.toolingBtn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.toolingBtn.FlatAppearance.BorderSize = 3
        Me.toolingBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.toolingBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.toolingBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.toolingBtn.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.toolingBtn.ForeColor = System.Drawing.Color.ForestGreen
        Me.toolingBtn.Location = New System.Drawing.Point(122, 12)
        Me.toolingBtn.Name = "toolingBtn"
        Me.toolingBtn.Size = New System.Drawing.Size(103, 38)
        Me.toolingBtn.TabIndex = 114
        Me.toolingBtn.Text = "Tooling"
        Me.toolingBtn.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.framesDishBtn)
        Me.Panel1.Controls.Add(Me.conformailDishBtn)
        Me.Panel1.Controls.Add(Me.Button11)
        Me.Panel1.Controls.Add(Me.routerDishBtn)
        Me.Panel1.Controls.Add(Me.PalletsRegularBtn)
        Me.Panel1.Controls.Add(Me.PalletsSelectiveBtn)
        Me.Panel1.Controls.Add(Me.SquegueBtn)
        Me.Panel1.Controls.Add(Me.FramesPalletsBtn)
        Me.Panel1.Controls.Add(Me.StencilBtn)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Location = New System.Drawing.Point(5, 58)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(20)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(673, 504)
        Me.Panel1.TabIndex = 58
        '
        'framesDishBtn
        '
        Me.framesDishBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.framesDishBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.framesDishBtn.FlatAppearance.BorderSize = 0
        Me.framesDishBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.framesDishBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.framesDishBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.framesDishBtn.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.framesDishBtn.ForeColor = System.Drawing.Color.White
        Me.framesDishBtn.Location = New System.Drawing.Point(467, 429)
        Me.framesDishBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.framesDishBtn.Name = "framesDishBtn"
        Me.framesDishBtn.Size = New System.Drawing.Size(123, 51)
        Me.framesDishBtn.TabIndex = 123
        Me.framesDishBtn.Text = "Frames"
        Me.framesDishBtn.UseVisualStyleBackColor = False
        '
        'conformailDishBtn
        '
        Me.conformailDishBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.conformailDishBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.conformailDishBtn.FlatAppearance.BorderSize = 0
        Me.conformailDishBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.conformailDishBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.conformailDishBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.conformailDishBtn.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.conformailDishBtn.ForeColor = System.Drawing.Color.White
        Me.conformailDishBtn.Location = New System.Drawing.Point(467, 365)
        Me.conformailDishBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.conformailDishBtn.Name = "conformailDishBtn"
        Me.conformailDishBtn.Size = New System.Drawing.Size(123, 51)
        Me.conformailDishBtn.TabIndex = 122
        Me.conformailDishBtn.Text = "Dish"
        Me.conformailDishBtn.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button11.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Button11.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.Button11.FlatAppearance.BorderSize = 3
        Me.Button11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button11.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.Button11.ForeColor = System.Drawing.Color.ForestGreen
        Me.Button11.Location = New System.Drawing.Point(367, 307)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(223, 38)
        Me.Button11.TabIndex = 121
        Me.Button11.Text = "Tooling of conformal"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'routerDishBtn
        '
        Me.routerDishBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.routerDishBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.routerDishBtn.FlatAppearance.BorderSize = 0
        Me.routerDishBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.routerDishBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.routerDishBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.routerDishBtn.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.routerDishBtn.ForeColor = System.Drawing.Color.White
        Me.routerDishBtn.Location = New System.Drawing.Point(116, 365)
        Me.routerDishBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.routerDishBtn.Name = "routerDishBtn"
        Me.routerDishBtn.Size = New System.Drawing.Size(123, 51)
        Me.routerDishBtn.TabIndex = 120
        Me.routerDishBtn.Text = "Dish"
        Me.routerDishBtn.UseVisualStyleBackColor = False
        '
        'PalletsRegularBtn
        '
        Me.PalletsRegularBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PalletsRegularBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.PalletsRegularBtn.FlatAppearance.BorderSize = 0
        Me.PalletsRegularBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.PalletsRegularBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.PalletsRegularBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.PalletsRegularBtn.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PalletsRegularBtn.ForeColor = System.Drawing.Color.White
        Me.PalletsRegularBtn.Location = New System.Drawing.Point(467, 182)
        Me.PalletsRegularBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.PalletsRegularBtn.Name = "PalletsRegularBtn"
        Me.PalletsRegularBtn.Size = New System.Drawing.Size(123, 51)
        Me.PalletsRegularBtn.TabIndex = 119
        Me.PalletsRegularBtn.Text = "Pallets regular"
        Me.PalletsRegularBtn.UseVisualStyleBackColor = False
        '
        'PalletsSelectiveBtn
        '
        Me.PalletsSelectiveBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PalletsSelectiveBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.PalletsSelectiveBtn.FlatAppearance.BorderSize = 0
        Me.PalletsSelectiveBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.PalletsSelectiveBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.PalletsSelectiveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.PalletsSelectiveBtn.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PalletsSelectiveBtn.ForeColor = System.Drawing.Color.White
        Me.PalletsSelectiveBtn.Location = New System.Drawing.Point(467, 115)
        Me.PalletsSelectiveBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.PalletsSelectiveBtn.Name = "PalletsSelectiveBtn"
        Me.PalletsSelectiveBtn.Size = New System.Drawing.Size(123, 51)
        Me.PalletsSelectiveBtn.TabIndex = 118
        Me.PalletsSelectiveBtn.Text = "Pallets selective"
        Me.PalletsSelectiveBtn.UseVisualStyleBackColor = False
        '
        'SquegueBtn
        '
        Me.SquegueBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SquegueBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.SquegueBtn.FlatAppearance.BorderSize = 0
        Me.SquegueBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.SquegueBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.SquegueBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.SquegueBtn.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SquegueBtn.ForeColor = System.Drawing.Color.White
        Me.SquegueBtn.Location = New System.Drawing.Point(116, 182)
        Me.SquegueBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.SquegueBtn.Name = "SquegueBtn"
        Me.SquegueBtn.Size = New System.Drawing.Size(123, 51)
        Me.SquegueBtn.TabIndex = 117
        Me.SquegueBtn.Text = "Squegue"
        Me.SquegueBtn.UseVisualStyleBackColor = False
        '
        'FramesPalletsBtn
        '
        Me.FramesPalletsBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FramesPalletsBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.FramesPalletsBtn.FlatAppearance.BorderSize = 0
        Me.FramesPalletsBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.FramesPalletsBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.FramesPalletsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.FramesPalletsBtn.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FramesPalletsBtn.ForeColor = System.Drawing.Color.White
        Me.FramesPalletsBtn.Location = New System.Drawing.Point(467, 246)
        Me.FramesPalletsBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.FramesPalletsBtn.Name = "FramesPalletsBtn"
        Me.FramesPalletsBtn.Size = New System.Drawing.Size(123, 51)
        Me.FramesPalletsBtn.TabIndex = 116
        Me.FramesPalletsBtn.Text = "Frames"
        Me.FramesPalletsBtn.UseVisualStyleBackColor = False
        '
        'StencilBtn
        '
        Me.StencilBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.StencilBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.StencilBtn.FlatAppearance.BorderSize = 0
        Me.StencilBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.StencilBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.StencilBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.StencilBtn.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StencilBtn.ForeColor = System.Drawing.Color.White
        Me.StencilBtn.Location = New System.Drawing.Point(116, 115)
        Me.StencilBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.StencilBtn.Name = "StencilBtn"
        Me.StencilBtn.Size = New System.Drawing.Size(123, 51)
        Me.StencilBtn.TabIndex = 115
        Me.StencilBtn.Text = "Stencil"
        Me.StencilBtn.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Button3.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.Button3.FlatAppearance.BorderSize = 3
        Me.Button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.Button3.ForeColor = System.Drawing.Color.ForestGreen
        Me.Button3.Location = New System.Drawing.Point(7, 307)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(232, 38)
        Me.Button3.TabIndex = 114
        Me.Button3.Text = "Tooling of Router"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Button2.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.Button2.FlatAppearance.BorderSize = 3
        Me.Button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.Button2.ForeColor = System.Drawing.Color.ForestGreen
        Me.Button2.Location = New System.Drawing.Point(367, 63)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(223, 38)
        Me.Button2.TabIndex = 113
        Me.Button2.Text = "Tooling Of WaveSolder"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.Button1.FlatAppearance.BorderSize = 3
        Me.Button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.Button1.ForeColor = System.Drawing.Color.ForestGreen
        Me.Button1.Location = New System.Drawing.Point(6, 63)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(233, 38)
        Me.Button1.TabIndex = 112
        Me.Button1.Text = "Tooling of SMT"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.AutoSize = True
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Panel3.Controls.Add(Me.Home1Btn)
        Me.Panel3.Controls.Add(Me.User)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(10, 3, 10, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(671, 47)
        Me.Panel3.TabIndex = 65
        '
        'Home1Btn
        '
        Me.Home1Btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Home1Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home1Btn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.Home1Btn.FlatAppearance.BorderSize = 3
        Me.Home1Btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home1Btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home1Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Home1Btn.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.Home1Btn.ForeColor = System.Drawing.Color.ForestGreen
        Me.Home1Btn.Location = New System.Drawing.Point(511, 6)
        Me.Home1Btn.Name = "Home1Btn"
        Me.Home1Btn.Size = New System.Drawing.Size(156, 38)
        Me.Home1Btn.TabIndex = 111
        Me.Home1Btn.Text = "Home"
        Me.Home1Btn.UseVisualStyleBackColor = False
        '
        'User
        '
        Me.User.AutoSize = True
        Me.User.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.User.ForeColor = System.Drawing.Color.White
        Me.User.Location = New System.Drawing.Point(31, 14)
        Me.User.Name = "User"
        Me.User.Size = New System.Drawing.Size(78, 19)
        Me.User.TabIndex = 109
        Me.User.Text = "Searchs..."
        '
        'viewDetailsBtnForm
        '
        Me.viewDetailsBtnForm.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.viewDetailsBtnForm.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.viewDetailsBtnForm.FlatAppearance.BorderSize = 0
        Me.viewDetailsBtnForm.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.viewDetailsBtnForm.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.viewDetailsBtnForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.viewDetailsBtnForm.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.viewDetailsBtnForm.ForeColor = System.Drawing.Color.White
        Me.viewDetailsBtnForm.Location = New System.Drawing.Point(1039, 395)
        Me.viewDetailsBtnForm.Margin = New System.Windows.Forms.Padding(0)
        Me.viewDetailsBtnForm.Name = "viewDetailsBtnForm"
        Me.viewDetailsBtnForm.Size = New System.Drawing.Size(123, 51)
        Me.viewDetailsBtnForm.TabIndex = 57
        Me.viewDetailsBtnForm.Text = "View details"
        Me.viewDetailsBtnForm.UseVisualStyleBackColor = False
        '
        'Tooling
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(683, 574)
        Me.Controls.Add(Me.PanelF)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.ForeColor = System.Drawing.Color.ForestGreen
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Tooling"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Tooling"
        Me.PanelF.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelF As System.Windows.Forms.Panel
    Friend WithEvents Home As System.Windows.Forms.Button
    Friend WithEvents toolingBtn As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Home1Btn As System.Windows.Forms.Button
    Friend WithEvents User As System.Windows.Forms.Label
    Friend WithEvents viewDetailsBtnForm As System.Windows.Forms.Button
    Friend WithEvents SquegueBtn As System.Windows.Forms.Button
    Friend WithEvents FramesPalletsBtn As System.Windows.Forms.Button
    Friend WithEvents StencilBtn As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents PalletsRegularBtn As System.Windows.Forms.Button
    Friend WithEvents PalletsSelectiveBtn As System.Windows.Forms.Button
    Friend WithEvents routerDishBtn As System.Windows.Forms.Button
    Friend WithEvents conformailDishBtn As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents framesDishBtn As System.Windows.Forms.Button
End Class
