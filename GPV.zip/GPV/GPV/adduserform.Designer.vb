﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class adduserform
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PanelF = New System.Windows.Forms.Panel()
        Me.AddUserBtn = New System.Windows.Forms.Button()
        Me.Home = New System.Windows.Forms.Button()
        Me.allUserBtn = New System.Windows.Forms.Button()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.AddStencilButton = New System.Windows.Forms.Button()
        Me.ReturnButton = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.allUser1Btn = New System.Windows.Forms.Button()
        Me.User = New System.Windows.Forms.Label()
        Me.LastName = New System.Windows.Forms.TextBox()
        Me.numberEmployer = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.lvlUserComboBox = New System.Windows.Forms.ComboBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.PanelF.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelF
        '
        Me.PanelF.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.PanelF.Controls.Add(Me.AddUserBtn)
        Me.PanelF.Controls.Add(Me.Home)
        Me.PanelF.Controls.Add(Me.allUserBtn)
        Me.PanelF.Controls.Add(Me.Panel6)
        Me.PanelF.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelF.Location = New System.Drawing.Point(0, 0)
        Me.PanelF.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelF.Name = "PanelF"
        Me.PanelF.Size = New System.Drawing.Size(683, 574)
        Me.PanelF.TabIndex = 108
        '
        'AddUserBtn
        '
        Me.AddUserBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.AddUserBtn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.AddUserBtn.FlatAppearance.BorderSize = 3
        Me.AddUserBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.AddUserBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.AddUserBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.AddUserBtn.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.AddUserBtn.ForeColor = System.Drawing.Color.ForestGreen
        Me.AddUserBtn.Location = New System.Drawing.Point(230, 12)
        Me.AddUserBtn.Name = "AddUserBtn"
        Me.AddUserBtn.Size = New System.Drawing.Size(111, 38)
        Me.AddUserBtn.TabIndex = 123
        Me.AddUserBtn.Text = "New User"
        Me.AddUserBtn.UseVisualStyleBackColor = False
        '
        'Home
        '
        Me.Home.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.Home.FlatAppearance.BorderSize = 3
        Me.Home.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Home.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.Home.ForeColor = System.Drawing.Color.ForestGreen
        Me.Home.Location = New System.Drawing.Point(12, 12)
        Me.Home.Name = "Home"
        Me.Home.Size = New System.Drawing.Size(103, 38)
        Me.Home.TabIndex = 122
        Me.Home.Text = "Home"
        Me.Home.UseVisualStyleBackColor = False
        '
        'allUserBtn
        '
        Me.allUserBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.allUserBtn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.allUserBtn.FlatAppearance.BorderSize = 3
        Me.allUserBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.allUserBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.allUserBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.allUserBtn.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.allUserBtn.ForeColor = System.Drawing.Color.ForestGreen
        Me.allUserBtn.Location = New System.Drawing.Point(121, 12)
        Me.allUserBtn.Name = "allUserBtn"
        Me.allUserBtn.Size = New System.Drawing.Size(103, 38)
        Me.allUserBtn.TabIndex = 121
        Me.allUserBtn.Text = "All users"
        Me.allUserBtn.UseVisualStyleBackColor = False
        '
        'Panel6
        '
        Me.Panel6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel6.Controls.Add(Me.AddStencilButton)
        Me.Panel6.Controls.Add(Me.ReturnButton)
        Me.Panel6.Controls.Add(Me.Panel3)
        Me.Panel6.Controls.Add(Me.LastName)
        Me.Panel6.Controls.Add(Me.numberEmployer)
        Me.Panel6.Controls.Add(Me.txtFirstName)
        Me.Panel6.Controls.Add(Me.lvlUserComboBox)
        Me.Panel6.Controls.Add(Me.txtPassword)
        Me.Panel6.Controls.Add(Me.txtEmail)
        Me.Panel6.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.Panel6.Location = New System.Drawing.Point(5, 58)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(20)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(673, 530)
        Me.Panel6.TabIndex = 4
        '
        'AddStencilButton
        '
        Me.AddStencilButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.AddStencilButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.AddStencilButton.FlatAppearance.BorderSize = 0
        Me.AddStencilButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.AddStencilButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.AddStencilButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.AddStencilButton.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddStencilButton.ForeColor = System.Drawing.Color.White
        Me.AddStencilButton.Location = New System.Drawing.Point(38, 330)
        Me.AddStencilButton.Margin = New System.Windows.Forms.Padding(0)
        Me.AddStencilButton.Name = "AddStencilButton"
        Me.AddStencilButton.Size = New System.Drawing.Size(240, 58)
        Me.AddStencilButton.TabIndex = 134
        Me.AddStencilButton.Text = "SAVE"
        Me.AddStencilButton.UseVisualStyleBackColor = False
        '
        'ReturnButton
        '
        Me.ReturnButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ReturnButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.ReturnButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.ReturnButton.FlatAppearance.BorderSize = 0
        Me.ReturnButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.ReturnButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.ReturnButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ReturnButton.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReturnButton.ForeColor = System.Drawing.Color.White
        Me.ReturnButton.Location = New System.Drawing.Point(315, 330)
        Me.ReturnButton.Margin = New System.Windows.Forms.Padding(5)
        Me.ReturnButton.Name = "ReturnButton"
        Me.ReturnButton.Size = New System.Drawing.Size(240, 58)
        Me.ReturnButton.TabIndex = 135
        Me.ReturnButton.Text = "Return"
        Me.ReturnButton.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.AutoSize = True
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Panel3.Controls.Add(Me.allUser1Btn)
        Me.Panel3.Controls.Add(Me.User)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(10, 3, 10, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(671, 47)
        Me.Panel3.TabIndex = 133
        '
        'allUser1Btn
        '
        Me.allUser1Btn.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.allUser1Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.allUser1Btn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.allUser1Btn.FlatAppearance.BorderSize = 3
        Me.allUser1Btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.allUser1Btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.allUser1Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.allUser1Btn.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.allUser1Btn.ForeColor = System.Drawing.Color.ForestGreen
        Me.allUser1Btn.Location = New System.Drawing.Point(511, 6)
        Me.allUser1Btn.Name = "allUser1Btn"
        Me.allUser1Btn.Size = New System.Drawing.Size(156, 38)
        Me.allUser1Btn.TabIndex = 111
        Me.allUser1Btn.Text = "View users"
        Me.allUser1Btn.UseVisualStyleBackColor = False
        '
        'User
        '
        Me.User.AutoSize = True
        Me.User.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.User.ForeColor = System.Drawing.Color.White
        Me.User.Location = New System.Drawing.Point(41, 25)
        Me.User.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.User.Name = "User"
        Me.User.Size = New System.Drawing.Size(66, 19)
        Me.User.TabIndex = 109
        Me.User.Text = "Medidas"
        '
        'LastName
        '
        Me.LastName.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LastName.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.LastName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.LastName.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LastName.ForeColor = System.Drawing.Color.ForestGreen
        Me.LastName.Location = New System.Drawing.Point(330, 178)
        Me.LastName.Margin = New System.Windows.Forms.Padding(5)
        Me.LastName.MaximumSize = New System.Drawing.Size(493, 40)
        Me.LastName.MaxLength = 50
        Me.LastName.MinimumSize = New System.Drawing.Size(133, 15)
        Me.LastName.Name = "LastName"
        Me.LastName.Size = New System.Drawing.Size(133, 20)
        Me.LastName.TabIndex = 104
        Me.LastName.Text = "Last Name"
        '
        'numberEmployer
        '
        Me.numberEmployer.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.numberEmployer.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.numberEmployer.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.numberEmployer.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.numberEmployer.ForeColor = System.Drawing.Color.ForestGreen
        Me.numberEmployer.Location = New System.Drawing.Point(81, 74)
        Me.numberEmployer.Margin = New System.Windows.Forms.Padding(0, 0, 0, 6)
        Me.numberEmployer.MaximumSize = New System.Drawing.Size(493, 40)
        Me.numberEmployer.MaxLength = 50
        Me.numberEmployer.MinimumSize = New System.Drawing.Size(133, 15)
        Me.numberEmployer.Name = "numberEmployer"
        Me.numberEmployer.Size = New System.Drawing.Size(133, 20)
        Me.numberEmployer.TabIndex = 53
        Me.numberEmployer.Text = "numberEmployer"
        '
        'txtFirstName
        '
        Me.txtFirstName.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtFirstName.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtFirstName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtFirstName.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFirstName.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtFirstName.Location = New System.Drawing.Point(81, 178)
        Me.txtFirstName.Margin = New System.Windows.Forms.Padding(5)
        Me.txtFirstName.MaximumSize = New System.Drawing.Size(493, 40)
        Me.txtFirstName.MaxLength = 50
        Me.txtFirstName.MinimumSize = New System.Drawing.Size(133, 15)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(133, 20)
        Me.txtFirstName.TabIndex = 55
        Me.txtFirstName.Text = "First Name"
        '
        'lvlUserComboBox
        '
        Me.lvlUserComboBox.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lvlUserComboBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.lvlUserComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.lvlUserComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lvlUserComboBox.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.lvlUserComboBox.ForeColor = System.Drawing.Color.ForestGreen
        Me.lvlUserComboBox.FormattingEnabled = True
        Me.lvlUserComboBox.Items.AddRange(New Object() {"Level", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.lvlUserComboBox.Location = New System.Drawing.Point(331, 271)
        Me.lvlUserComboBox.Margin = New System.Windows.Forms.Padding(0)
        Me.lvlUserComboBox.Name = "lvlUserComboBox"
        Me.lvlUserComboBox.Size = New System.Drawing.Size(55, 27)
        Me.lvlUserComboBox.TabIndex = 103
        '
        'txtPassword
        '
        Me.txtPassword.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPassword.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtPassword.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPassword.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtPassword.Location = New System.Drawing.Point(81, 274)
        Me.txtPassword.Margin = New System.Windows.Forms.Padding(5)
        Me.txtPassword.MaximumSize = New System.Drawing.Size(493, 40)
        Me.txtPassword.MaxLength = 30
        Me.txtPassword.MinimumSize = New System.Drawing.Size(133, 15)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(133, 20)
        Me.txtPassword.TabIndex = 92
        Me.txtPassword.Text = "Password"
        '
        'txtEmail
        '
        Me.txtEmail.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtEmail.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtEmail.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmail.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtEmail.Location = New System.Drawing.Point(331, 74)
        Me.txtEmail.Margin = New System.Windows.Forms.Padding(5)
        Me.txtEmail.MaximumSize = New System.Drawing.Size(493, 40)
        Me.txtEmail.MaxLength = 30
        Me.txtEmail.MinimumSize = New System.Drawing.Size(133, 15)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(133, 20)
        Me.txtEmail.TabIndex = 87
        Me.txtEmail.Text = "E-mail"
        '
        'adduserform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(683, 574)
        Me.Controls.Add(Me.PanelF)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.ForeColor = System.Drawing.Color.ForestGreen
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "adduserform"
        Me.Text = "adduserform"
        Me.PanelF.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelF As System.Windows.Forms.Panel
    Friend WithEvents AddUserBtn As System.Windows.Forms.Button
    Friend WithEvents Home As System.Windows.Forms.Button
    Friend WithEvents allUserBtn As System.Windows.Forms.Button
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents AddStencilButton As System.Windows.Forms.Button
    Friend WithEvents ReturnButton As System.Windows.Forms.Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents allUser1Btn As System.Windows.Forms.Button
    Friend WithEvents User As System.Windows.Forms.Label
    Friend WithEvents LastName As System.Windows.Forms.TextBox
    Friend WithEvents numberEmployer As System.Windows.Forms.TextBox
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents lvlUserComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
End Class
