﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class alluser
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.PanelF = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.textBoxFindStencil = New System.Windows.Forms.TextBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.HomeBtn = New System.Windows.Forms.Button()
        Me.User = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.allUserTable = New System.Windows.Forms.TabPage()
        Me.aplicar = New System.Windows.Forms.Button()
        Me.EjectOptionComboBox = New System.Windows.Forms.ComboBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.AddUserBtnForm = New System.Windows.Forms.Button()
        Me.superUserTable = New System.Windows.Forms.TabPage()
        Me.Home = New System.Windows.Forms.Button()
        Me.allUserBtn = New System.Windows.Forms.Button()
        Me.viewDetailsBtnForm = New System.Windows.Forms.Button()
        Me.PanelF.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.allUserTable.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PanelF
        '
        Me.PanelF.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.PanelF.Controls.Add(Me.Panel6)
        Me.PanelF.Controls.Add(Me.Home)
        Me.PanelF.Controls.Add(Me.allUserBtn)
        Me.PanelF.Controls.Add(Me.viewDetailsBtnForm)
        Me.PanelF.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelF.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PanelF.Location = New System.Drawing.Point(0, 0)
        Me.PanelF.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelF.Name = "PanelF"
        Me.PanelF.Size = New System.Drawing.Size(667, 535)
        Me.PanelF.TabIndex = 39
        '
        'Panel6
        '
        Me.Panel6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel6.Controls.Add(Me.textBoxFindStencil)
        Me.Panel6.Controls.Add(Me.Panel3)
        Me.Panel6.Controls.Add(Me.TabControl1)
        Me.Panel6.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.Panel6.Location = New System.Drawing.Point(8, 58)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(20)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(657, 466)
        Me.Panel6.TabIndex = 131
        '
        'textBoxFindStencil
        '
        Me.textBoxFindStencil.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxFindStencil.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.textBoxFindStencil.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.textBoxFindStencil.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.textBoxFindStencil.ForeColor = System.Drawing.Color.ForestGreen
        Me.textBoxFindStencil.Location = New System.Drawing.Point(373, 57)
        Me.textBoxFindStencil.Margin = New System.Windows.Forms.Padding(4)
        Me.textBoxFindStencil.MaximumSize = New System.Drawing.Size(300, 30)
        Me.textBoxFindStencil.MinimumSize = New System.Drawing.Size(200, 15)
        Me.textBoxFindStencil.Name = "textBoxFindStencil"
        Me.textBoxFindStencil.Size = New System.Drawing.Size(280, 26)
        Me.textBoxFindStencil.TabIndex = 135
        Me.textBoxFindStencil.Text = "Find Stencil"
        '
        'Panel3
        '
        Me.Panel3.AutoSize = True
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Panel3.Controls.Add(Me.HomeBtn)
        Me.Panel3.Controls.Add(Me.User)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(10, 3, 10, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(655, 47)
        Me.Panel3.TabIndex = 133
        '
        'HomeBtn
        '
        Me.HomeBtn.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.HomeBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.HomeBtn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.HomeBtn.FlatAppearance.BorderSize = 3
        Me.HomeBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.HomeBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.HomeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.HomeBtn.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.HomeBtn.ForeColor = System.Drawing.Color.ForestGreen
        Me.HomeBtn.Location = New System.Drawing.Point(511, 6)
        Me.HomeBtn.Name = "HomeBtn"
        Me.HomeBtn.Size = New System.Drawing.Size(140, 38)
        Me.HomeBtn.TabIndex = 111
        Me.HomeBtn.Text = "Home"
        Me.HomeBtn.UseVisualStyleBackColor = False
        '
        'User
        '
        Me.User.AutoSize = True
        Me.User.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.User.ForeColor = System.Drawing.Color.White
        Me.User.Location = New System.Drawing.Point(7, 17)
        Me.User.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.User.Name = "User"
        Me.User.Size = New System.Drawing.Size(66, 19)
        Me.User.TabIndex = 109
        Me.User.Text = "Medidas"
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.allUserTable)
        Me.TabControl1.Controls.Add(Me.superUserTable)
        Me.TabControl1.Location = New System.Drawing.Point(4, 54)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(4)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(651, 393)
        Me.TabControl1.TabIndex = 134
        '
        'allUserTable
        '
        Me.allUserTable.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.allUserTable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.allUserTable.Controls.Add(Me.aplicar)
        Me.allUserTable.Controls.Add(Me.EjectOptionComboBox)
        Me.allUserTable.Controls.Add(Me.DataGridView1)
        Me.allUserTable.Controls.Add(Me.AddUserBtnForm)
        Me.allUserTable.ForeColor = System.Drawing.Color.ForestGreen
        Me.allUserTable.Location = New System.Drawing.Point(4, 28)
        Me.allUserTable.Margin = New System.Windows.Forms.Padding(4)
        Me.allUserTable.Name = "allUserTable"
        Me.allUserTable.Padding = New System.Windows.Forms.Padding(4)
        Me.allUserTable.Size = New System.Drawing.Size(643, 361)
        Me.allUserTable.TabIndex = 0
        Me.allUserTable.Text = "All"
        '
        'aplicar
        '
        Me.aplicar.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.aplicar.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.aplicar.FlatAppearance.BorderSize = 3
        Me.aplicar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.aplicar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.aplicar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.aplicar.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.aplicar.ForeColor = System.Drawing.Color.ForestGreen
        Me.aplicar.Location = New System.Drawing.Point(274, 283)
        Me.aplicar.Margin = New System.Windows.Forms.Padding(4)
        Me.aplicar.Name = "aplicar"
        Me.aplicar.Size = New System.Drawing.Size(119, 44)
        Me.aplicar.TabIndex = 105
        Me.aplicar.Text = "Aplicar"
        Me.aplicar.UseVisualStyleBackColor = False
        '
        'EjectOptionComboBox
        '
        Me.EjectOptionComboBox.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.EjectOptionComboBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.EjectOptionComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.EjectOptionComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.EjectOptionComboBox.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.EjectOptionComboBox.ForeColor = System.Drawing.Color.ForestGreen
        Me.EjectOptionComboBox.FormattingEnabled = True
        Me.EjectOptionComboBox.Items.AddRange(New Object() {"Seleccione accion", "Delete user", "Log user"})
        Me.EjectOptionComboBox.Location = New System.Drawing.Point(24, 291)
        Me.EjectOptionComboBox.Margin = New System.Windows.Forms.Padding(0)
        Me.EjectOptionComboBox.MaximumSize = New System.Drawing.Size(224, 0)
        Me.EjectOptionComboBox.MinimumSize = New System.Drawing.Size(224, 0)
        Me.EjectOptionComboBox.Name = "EjectOptionComboBox"
        Me.EjectOptionComboBox.Size = New System.Drawing.Size(224, 27)
        Me.EjectOptionComboBox.TabIndex = 104
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(30, Byte), Integer))
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Tahoma", 12.0!)
        DataGridViewCellStyle13.ForeColor = System.Drawing.Color.ForestGreen
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle13
        Me.DataGridView1.EnableHeadersVisualStyles = False
        Me.DataGridView1.Location = New System.Drawing.Point(24, 15)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(0)
        Me.DataGridView1.Name = "DataGridView1"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Tahoma", 12.0!)
        DataGridViewCellStyle14.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle14
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.ShowEditingIcon = False
        Me.DataGridView1.Size = New System.Drawing.Size(573, 258)
        Me.DataGridView1.TabIndex = 46
        '
        'AddUserBtnForm
        '
        Me.AddUserBtnForm.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.AddUserBtnForm.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.AddUserBtnForm.FlatAppearance.BorderSize = 0
        Me.AddUserBtnForm.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.AddUserBtnForm.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.AddUserBtnForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.AddUserBtnForm.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddUserBtnForm.ForeColor = System.Drawing.Color.White
        Me.AddUserBtnForm.Location = New System.Drawing.Point(423, 283)
        Me.AddUserBtnForm.Margin = New System.Windows.Forms.Padding(0)
        Me.AddUserBtnForm.Name = "AddUserBtnForm"
        Me.AddUserBtnForm.Size = New System.Drawing.Size(159, 41)
        Me.AddUserBtnForm.TabIndex = 54
        Me.AddUserBtnForm.Text = "Editar user"
        Me.AddUserBtnForm.UseVisualStyleBackColor = False
        '
        'superUserTable
        '
        Me.superUserTable.ForeColor = System.Drawing.Color.ForestGreen
        Me.superUserTable.Location = New System.Drawing.Point(4, 28)
        Me.superUserTable.Margin = New System.Windows.Forms.Padding(4)
        Me.superUserTable.Name = "superUserTable"
        Me.superUserTable.Padding = New System.Windows.Forms.Padding(4)
        Me.superUserTable.Size = New System.Drawing.Size(643, 361)
        Me.superUserTable.TabIndex = 1
        Me.superUserTable.Text = "Super User"
        Me.superUserTable.UseVisualStyleBackColor = True
        '
        'Home
        '
        Me.Home.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.Home.FlatAppearance.BorderSize = 3
        Me.Home.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Home.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.Home.ForeColor = System.Drawing.Color.ForestGreen
        Me.Home.Location = New System.Drawing.Point(15, 12)
        Me.Home.Name = "Home"
        Me.Home.Size = New System.Drawing.Size(103, 38)
        Me.Home.TabIndex = 129
        Me.Home.Text = "Home"
        Me.Home.UseVisualStyleBackColor = False
        '
        'allUserBtn
        '
        Me.allUserBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.allUserBtn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.allUserBtn.FlatAppearance.BorderSize = 3
        Me.allUserBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.allUserBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.allUserBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.allUserBtn.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.allUserBtn.ForeColor = System.Drawing.Color.ForestGreen
        Me.allUserBtn.Location = New System.Drawing.Point(124, 12)
        Me.allUserBtn.Name = "allUserBtn"
        Me.allUserBtn.Size = New System.Drawing.Size(103, 38)
        Me.allUserBtn.TabIndex = 128
        Me.allUserBtn.Text = "All users"
        Me.allUserBtn.UseVisualStyleBackColor = False
        '
        'viewDetailsBtnForm
        '
        Me.viewDetailsBtnForm.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.viewDetailsBtnForm.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.viewDetailsBtnForm.FlatAppearance.BorderSize = 0
        Me.viewDetailsBtnForm.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.viewDetailsBtnForm.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.viewDetailsBtnForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.viewDetailsBtnForm.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.viewDetailsBtnForm.ForeColor = System.Drawing.Color.White
        Me.viewDetailsBtnForm.Location = New System.Drawing.Point(1141, 486)
        Me.viewDetailsBtnForm.Margin = New System.Windows.Forms.Padding(0)
        Me.viewDetailsBtnForm.Name = "viewDetailsBtnForm"
        Me.viewDetailsBtnForm.Size = New System.Drawing.Size(164, 63)
        Me.viewDetailsBtnForm.TabIndex = 57
        Me.viewDetailsBtnForm.Text = "View details"
        Me.viewDetailsBtnForm.UseVisualStyleBackColor = False
        '
        'alluser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(667, 535)
        Me.Controls.Add(Me.PanelF)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.ForeColor = System.Drawing.Color.ForestGreen
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "alluser"
        Me.Text = "panelmanageruser"
        Me.PanelF.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.allUserTable.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelF As System.Windows.Forms.Panel
    Friend WithEvents viewDetailsBtnForm As System.Windows.Forms.Button
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents allUserTable As System.Windows.Forms.TabPage
    Friend WithEvents aplicar As System.Windows.Forms.Button
    Friend WithEvents EjectOptionComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents AddUserBtnForm As System.Windows.Forms.Button
    Friend WithEvents superUserTable As System.Windows.Forms.TabPage
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents HomeBtn As System.Windows.Forms.Button
    Friend WithEvents User As System.Windows.Forms.Label
    Friend WithEvents Home As System.Windows.Forms.Button
    Friend WithEvents allUserBtn As System.Windows.Forms.Button
    Friend WithEvents textBoxFindStencil As System.Windows.Forms.TextBox
End Class
