﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class editrouterdishform
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PanelF = New System.Windows.Forms.Panel()
        Me.EditDishBtn = New System.Windows.Forms.Button()
        Me.DishToolBtn = New System.Windows.Forms.Button()
        Me.Home = New System.Windows.Forms.Button()
        Me.toolingBtn = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Cicles = New System.Windows.Forms.TextBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.DishTool1Btn = New System.Windows.Forms.Button()
        Me.edit = New System.Windows.Forms.Label()
        Me.proyectName = New System.Windows.Forms.ComboBox()
        Me.provedorName = New System.Windows.Forms.ComboBox()
        Me.localidadStencil = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtCommentsStencilEdit = New System.Windows.Forms.RichTextBox()
        Me.txtYPCBEdit = New System.Windows.Forms.TextBox()
        Me.txtNumberPartPCBEdit = New System.Windows.Forms.TextBox()
        Me.DateMakeJob = New System.Windows.Forms.DateTimePicker()
        Me.txtJobStencilEdit = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtXPCBEdit = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtRevStencilEdit = New System.Windows.Forms.TextBox()
        Me.txtStencilNameEdit = New System.Windows.Forms.TextBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Roperator = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ListView3 = New System.Windows.Forms.ListView()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.PanelF.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelF
        '
        Me.PanelF.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.PanelF.Controls.Add(Me.EditDishBtn)
        Me.PanelF.Controls.Add(Me.DishToolBtn)
        Me.PanelF.Controls.Add(Me.Home)
        Me.PanelF.Controls.Add(Me.toolingBtn)
        Me.PanelF.Controls.Add(Me.Panel1)
        Me.PanelF.Controls.Add(Me.ListView3)
        Me.PanelF.Controls.Add(Me.Label21)
        Me.PanelF.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelF.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PanelF.ForeColor = System.Drawing.Color.ForestGreen
        Me.PanelF.Location = New System.Drawing.Point(0, 0)
        Me.PanelF.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelF.Name = "PanelF"
        Me.PanelF.Size = New System.Drawing.Size(683, 574)
        Me.PanelF.TabIndex = 42
        '
        'EditDishBtn
        '
        Me.EditDishBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.EditDishBtn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.EditDishBtn.FlatAppearance.BorderSize = 3
        Me.EditDishBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.EditDishBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.EditDishBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.EditDishBtn.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.EditDishBtn.ForeColor = System.Drawing.Color.ForestGreen
        Me.EditDishBtn.Location = New System.Drawing.Point(340, 12)
        Me.EditDishBtn.Name = "EditDishBtn"
        Me.EditDishBtn.Size = New System.Drawing.Size(122, 38)
        Me.EditDishBtn.TabIndex = 124
        Me.EditDishBtn.Text = "Edit Dishs"
        Me.EditDishBtn.UseVisualStyleBackColor = False
        '
        'DishToolBtn
        '
        Me.DishToolBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.DishToolBtn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.DishToolBtn.FlatAppearance.BorderSize = 3
        Me.DishToolBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.DishToolBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.DishToolBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.DishToolBtn.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.DishToolBtn.ForeColor = System.Drawing.Color.ForestGreen
        Me.DishToolBtn.Location = New System.Drawing.Point(231, 12)
        Me.DishToolBtn.Name = "DishToolBtn"
        Me.DishToolBtn.Size = New System.Drawing.Size(103, 38)
        Me.DishToolBtn.TabIndex = 123
        Me.DishToolBtn.Text = "Dish"
        Me.DishToolBtn.UseVisualStyleBackColor = False
        '
        'Home
        '
        Me.Home.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.Home.FlatAppearance.BorderSize = 3
        Me.Home.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Home.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.Home.ForeColor = System.Drawing.Color.ForestGreen
        Me.Home.Location = New System.Drawing.Point(13, 12)
        Me.Home.Name = "Home"
        Me.Home.Size = New System.Drawing.Size(103, 38)
        Me.Home.TabIndex = 122
        Me.Home.Text = "Home"
        Me.Home.UseVisualStyleBackColor = False
        '
        'toolingBtn
        '
        Me.toolingBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.toolingBtn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.toolingBtn.FlatAppearance.BorderSize = 3
        Me.toolingBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.toolingBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.toolingBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.toolingBtn.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.toolingBtn.ForeColor = System.Drawing.Color.ForestGreen
        Me.toolingBtn.Location = New System.Drawing.Point(122, 12)
        Me.toolingBtn.Name = "toolingBtn"
        Me.toolingBtn.Size = New System.Drawing.Size(103, 38)
        Me.toolingBtn.TabIndex = 121
        Me.toolingBtn.Text = "Tooling"
        Me.toolingBtn.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.TextBox4)
        Me.Panel1.Controls.Add(Me.TextBox3)
        Me.Panel1.Controls.Add(Me.ComboBox1)
        Me.Panel1.Controls.Add(Me.TextBox1)
        Me.Panel1.Controls.Add(Me.TextBox2)
        Me.Panel1.Controls.Add(Me.Cicles)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.proyectName)
        Me.Panel1.Controls.Add(Me.provedorName)
        Me.Panel1.Controls.Add(Me.localidadStencil)
        Me.Panel1.Controls.Add(Me.Label22)
        Me.Panel1.Controls.Add(Me.txtCommentsStencilEdit)
        Me.Panel1.Controls.Add(Me.txtYPCBEdit)
        Me.Panel1.Controls.Add(Me.txtNumberPartPCBEdit)
        Me.Panel1.Controls.Add(Me.DateMakeJob)
        Me.Panel1.Controls.Add(Me.txtJobStencilEdit)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.txtXPCBEdit)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.txtRevStencilEdit)
        Me.Panel1.Controls.Add(Me.txtStencilNameEdit)
        Me.Panel1.Controls.Add(Me.Panel4)
        Me.Panel1.Location = New System.Drawing.Point(5, 58)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(20)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(673, 504)
        Me.Panel1.TabIndex = 103
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(386, 93)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(132, 25)
        Me.Label1.TabIndex = 145
        Me.Label1.Text = "Panel array"
        '
        'TextBox4
        '
        Me.TextBox4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.TextBox4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox4.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.ForeColor = System.Drawing.Color.ForestGreen
        Me.TextBox4.Location = New System.Drawing.Point(391, 170)
        Me.TextBox4.Margin = New System.Windows.Forms.Padding(0, 0, 0, 6)
        Me.TextBox4.MaximumSize = New System.Drawing.Size(493, 40)
        Me.TextBox4.MaxLength = 50
        Me.TextBox4.MinimumSize = New System.Drawing.Size(133, 15)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(155, 20)
        Me.TextBox4.TabIndex = 144
        Me.TextBox4.Text = "Qty imagenes"
        '
        'TextBox3
        '
        Me.TextBox3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox3.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.ForeColor = System.Drawing.Color.ForestGreen
        Me.TextBox3.Location = New System.Drawing.Point(391, 249)
        Me.TextBox3.Margin = New System.Windows.Forms.Padding(0, 0, 0, 6)
        Me.TextBox3.MaximumSize = New System.Drawing.Size(493, 40)
        Me.TextBox3.MaxLength = 50
        Me.TextBox3.MinimumSize = New System.Drawing.Size(133, 15)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(155, 20)
        Me.TextBox3.TabIndex = 143
        Me.TextBox3.Text = "ID dish"
        '
        'ComboBox1
        '
        Me.ComboBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.ComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ComboBox1.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.ComboBox1.ForeColor = System.Drawing.Color.ForestGreen
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Provedor", "Prueba"})
        Me.ComboBox1.Location = New System.Drawing.Point(391, 208)
        Me.ComboBox1.Margin = New System.Windows.Forms.Padding(0)
        Me.ComboBox1.MaximumSize = New System.Drawing.Size(155, 0)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(152, 27)
        Me.ComboBox1.TabIndex = 142
        Me.ComboBox1.Tag = "Proyecto"
        Me.ComboBox1.Text = "Machine"
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.Color.ForestGreen
        Me.TextBox1.Location = New System.Drawing.Point(496, 138)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(5)
        Me.TextBox1.MaximumSize = New System.Drawing.Size(93, 40)
        Me.TextBox1.MaxLength = 30
        Me.TextBox1.MinimumSize = New System.Drawing.Size(40, 15)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(88, 20)
        Me.TextBox1.TabIndex = 140
        Me.TextBox1.Text = "Y "
        '
        'TextBox2
        '
        Me.TextBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox2.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.ForeColor = System.Drawing.Color.ForestGreen
        Me.TextBox2.Location = New System.Drawing.Point(391, 138)
        Me.TextBox2.Margin = New System.Windows.Forms.Padding(5)
        Me.TextBox2.MaximumSize = New System.Drawing.Size(93, 40)
        Me.TextBox2.MaxLength = 30
        Me.TextBox2.MinimumSize = New System.Drawing.Size(40, 15)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(88, 20)
        Me.TextBox2.TabIndex = 139
        Me.TextBox2.Text = "X"
        '
        'Cicles
        '
        Me.Cicles.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Cicles.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Cicles.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Cicles.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cicles.ForeColor = System.Drawing.Color.ForestGreen
        Me.Cicles.Location = New System.Drawing.Point(391, 65)
        Me.Cicles.Margin = New System.Windows.Forms.Padding(5)
        Me.Cicles.MaximumSize = New System.Drawing.Size(493, 40)
        Me.Cicles.MaxLength = 50
        Me.Cicles.MinimumSize = New System.Drawing.Size(133, 15)
        Me.Cicles.Name = "Cicles"
        Me.Cicles.Size = New System.Drawing.Size(155, 20)
        Me.Cicles.TabIndex = 138
        Me.Cicles.Text = "Cycles"
        '
        'Panel3
        '
        Me.Panel3.AutoSize = True
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Panel3.Controls.Add(Me.DishTool1Btn)
        Me.Panel3.Controls.Add(Me.edit)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(10, 3, 10, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(671, 47)
        Me.Panel3.TabIndex = 137
        '
        'DishTool1Btn
        '
        Me.DishTool1Btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DishTool1Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.DishTool1Btn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.DishTool1Btn.FlatAppearance.BorderSize = 3
        Me.DishTool1Btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.DishTool1Btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.DishTool1Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.DishTool1Btn.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.DishTool1Btn.ForeColor = System.Drawing.Color.ForestGreen
        Me.DishTool1Btn.Location = New System.Drawing.Point(511, 6)
        Me.DishTool1Btn.Name = "DishTool1Btn"
        Me.DishTool1Btn.Size = New System.Drawing.Size(156, 38)
        Me.DishTool1Btn.TabIndex = 111
        Me.DishTool1Btn.Text = "Dishs"
        Me.DishTool1Btn.UseVisualStyleBackColor = False
        '
        'edit
        '
        Me.edit.AutoSize = True
        Me.edit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.edit.ForeColor = System.Drawing.Color.White
        Me.edit.Location = New System.Drawing.Point(31, 14)
        Me.edit.Name = "edit"
        Me.edit.Size = New System.Drawing.Size(123, 19)
        Me.edit.TabIndex = 109
        Me.edit.Text = "Edit router plate"
        '
        'proyectName
        '
        Me.proyectName.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.proyectName.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.proyectName.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.proyectName.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.proyectName.ForeColor = System.Drawing.Color.ForestGreen
        Me.proyectName.FormattingEnabled = True
        Me.proyectName.Items.AddRange(New Object() {"Provedor", "Prueba"})
        Me.proyectName.Location = New System.Drawing.Point(140, 135)
        Me.proyectName.Margin = New System.Windows.Forms.Padding(0)
        Me.proyectName.MaximumSize = New System.Drawing.Size(155, 0)
        Me.proyectName.Name = "proyectName"
        Me.proyectName.Size = New System.Drawing.Size(152, 27)
        Me.proyectName.TabIndex = 136
        Me.proyectName.Tag = "Proyecto"
        Me.proyectName.Text = "Proyecto"
        '
        'provedorName
        '
        Me.provedorName.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.provedorName.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.provedorName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.provedorName.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.provedorName.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.provedorName.ForeColor = System.Drawing.Color.ForestGreen
        Me.provedorName.FormattingEnabled = True
        Me.provedorName.Items.AddRange(New Object() {"Provedor", "Prueba"})
        Me.provedorName.Location = New System.Drawing.Point(139, 275)
        Me.provedorName.Margin = New System.Windows.Forms.Padding(0)
        Me.provedorName.MaximumSize = New System.Drawing.Size(155, 0)
        Me.provedorName.Name = "provedorName"
        Me.provedorName.Size = New System.Drawing.Size(152, 27)
        Me.provedorName.TabIndex = 134
        '
        'localidadStencil
        '
        Me.localidadStencil.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.localidadStencil.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.localidadStencil.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.localidadStencil.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.localidadStencil.ForeColor = System.Drawing.Color.ForestGreen
        Me.localidadStencil.Location = New System.Drawing.Point(139, 380)
        Me.localidadStencil.Margin = New System.Windows.Forms.Padding(5)
        Me.localidadStencil.MaximumSize = New System.Drawing.Size(493, 40)
        Me.localidadStencil.MaxLength = 50
        Me.localidadStencil.MinimumSize = New System.Drawing.Size(133, 15)
        Me.localidadStencil.Name = "localidadStencil"
        Me.localidadStencil.Size = New System.Drawing.Size(133, 20)
        Me.localidadStencil.TabIndex = 133
        Me.localidadStencil.Text = "Localidad"
        '
        'Label22
        '
        Me.Label22.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(386, 275)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(113, 23)
        Me.Label22.TabIndex = 123
        Me.Label22.Text = "Comentarios"
        '
        'txtCommentsStencilEdit
        '
        Me.txtCommentsStencilEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtCommentsStencilEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtCommentsStencilEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCommentsStencilEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtCommentsStencilEdit.Location = New System.Drawing.Point(391, 298)
        Me.txtCommentsStencilEdit.Margin = New System.Windows.Forms.Padding(0)
        Me.txtCommentsStencilEdit.MaximumSize = New System.Drawing.Size(467, 172)
        Me.txtCommentsStencilEdit.MinimumSize = New System.Drawing.Size(213, 86)
        Me.txtCommentsStencilEdit.Name = "txtCommentsStencilEdit"
        Me.txtCommentsStencilEdit.Size = New System.Drawing.Size(213, 86)
        Me.txtCommentsStencilEdit.TabIndex = 124
        Me.txtCommentsStencilEdit.Text = "Ingrese comentarios"
        '
        'txtYPCBEdit
        '
        Me.txtYPCBEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtYPCBEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtYPCBEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtYPCBEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtYPCBEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtYPCBEdit.Location = New System.Drawing.Point(237, 240)
        Me.txtYPCBEdit.Margin = New System.Windows.Forms.Padding(5)
        Me.txtYPCBEdit.MaximumSize = New System.Drawing.Size(93, 40)
        Me.txtYPCBEdit.MaxLength = 30
        Me.txtYPCBEdit.MinimumSize = New System.Drawing.Size(40, 15)
        Me.txtYPCBEdit.Name = "txtYPCBEdit"
        Me.txtYPCBEdit.Size = New System.Drawing.Size(88, 20)
        Me.txtYPCBEdit.TabIndex = 125
        Me.txtYPCBEdit.Text = "Y Width"
        '
        'txtNumberPartPCBEdit
        '
        Me.txtNumberPartPCBEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNumberPartPCBEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtNumberPartPCBEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtNumberPartPCBEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNumberPartPCBEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtNumberPartPCBEdit.Location = New System.Drawing.Point(140, 100)
        Me.txtNumberPartPCBEdit.Margin = New System.Windows.Forms.Padding(5)
        Me.txtNumberPartPCBEdit.MaximumSize = New System.Drawing.Size(493, 40)
        Me.txtNumberPartPCBEdit.MaxLength = 50
        Me.txtNumberPartPCBEdit.MinimumSize = New System.Drawing.Size(133, 15)
        Me.txtNumberPartPCBEdit.Name = "txtNumberPartPCBEdit"
        Me.txtNumberPartPCBEdit.Size = New System.Drawing.Size(155, 20)
        Me.txtNumberPartPCBEdit.TabIndex = 108
        Me.txtNumberPartPCBEdit.Text = "PCB"
        '
        'DateMakeJob
        '
        Me.DateMakeJob.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DateMakeJob.CalendarForeColor = System.Drawing.Color.ForestGreen
        Me.DateMakeJob.CalendarMonthBackground = System.Drawing.Color.ForestGreen
        Me.DateMakeJob.CalendarTitleBackColor = System.Drawing.Color.ForestGreen
        Me.DateMakeJob.CalendarTitleForeColor = System.Drawing.Color.ForestGreen
        Me.DateMakeJob.CalendarTrailingForeColor = System.Drawing.Color.ForestGreen
        Me.DateMakeJob.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateMakeJob.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateMakeJob.Location = New System.Drawing.Point(140, 170)
        Me.DateMakeJob.Margin = New System.Windows.Forms.Padding(4)
        Me.DateMakeJob.MaxDate = New Date(2099, 12, 31, 0, 0, 0, 0)
        Me.DateMakeJob.MaximumSize = New System.Drawing.Size(150, 40)
        Me.DateMakeJob.MinDate = New Date(2010, 1, 1, 0, 0, 0, 0)
        Me.DateMakeJob.MinimumSize = New System.Drawing.Size(132, 4)
        Me.DateMakeJob.Name = "DateMakeJob"
        Me.DateMakeJob.Size = New System.Drawing.Size(150, 27)
        Me.DateMakeJob.TabIndex = 112
        '
        'txtJobStencilEdit
        '
        Me.txtJobStencilEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtJobStencilEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtJobStencilEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtJobStencilEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtJobStencilEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtJobStencilEdit.Location = New System.Drawing.Point(139, 345)
        Me.txtJobStencilEdit.Margin = New System.Windows.Forms.Padding(5)
        Me.txtJobStencilEdit.MaximumSize = New System.Drawing.Size(493, 40)
        Me.txtJobStencilEdit.MaxLength = 30
        Me.txtJobStencilEdit.MinimumSize = New System.Drawing.Size(133, 15)
        Me.txtJobStencilEdit.Name = "txtJobStencilEdit"
        Me.txtJobStencilEdit.Size = New System.Drawing.Size(196, 20)
        Me.txtJobStencilEdit.TabIndex = 122
        Me.txtJobStencilEdit.Text = "Job"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(5, 176)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(130, 19)
        Me.Label10.TabIndex = 113
        Me.Label10.Text = "Fecha fabricacion"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(60, 278)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(73, 19)
        Me.Label9.TabIndex = 111
        Me.Label9.Text = "Provedor"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(62, 137)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(70, 19)
        Me.Label17.TabIndex = 120
        Me.Label17.Text = "Proyecto"
        '
        'txtXPCBEdit
        '
        Me.txtXPCBEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtXPCBEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtXPCBEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtXPCBEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtXPCBEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtXPCBEdit.Location = New System.Drawing.Point(140, 240)
        Me.txtXPCBEdit.Margin = New System.Windows.Forms.Padding(5)
        Me.txtXPCBEdit.MaximumSize = New System.Drawing.Size(93, 40)
        Me.txtXPCBEdit.MaxLength = 30
        Me.txtXPCBEdit.MinimumSize = New System.Drawing.Size(40, 15)
        Me.txtXPCBEdit.Name = "txtXPCBEdit"
        Me.txtXPCBEdit.Size = New System.Drawing.Size(88, 20)
        Me.txtXPCBEdit.TabIndex = 115
        Me.txtXPCBEdit.Text = "X Lengh"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(66, 211)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(66, 19)
        Me.Label8.TabIndex = 110
        Me.Label8.Text = "Medidas"
        '
        'txtRevStencilEdit
        '
        Me.txtRevStencilEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtRevStencilEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtRevStencilEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtRevStencilEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRevStencilEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtRevStencilEdit.Location = New System.Drawing.Point(139, 310)
        Me.txtRevStencilEdit.Margin = New System.Windows.Forms.Padding(5)
        Me.txtRevStencilEdit.MaximumSize = New System.Drawing.Size(493, 40)
        Me.txtRevStencilEdit.MaxLength = 30
        Me.txtRevStencilEdit.MinimumSize = New System.Drawing.Size(133, 15)
        Me.txtRevStencilEdit.Name = "txtRevStencilEdit"
        Me.txtRevStencilEdit.Size = New System.Drawing.Size(196, 20)
        Me.txtRevStencilEdit.TabIndex = 119
        Me.txtRevStencilEdit.Text = "Revision"
        '
        'txtStencilNameEdit
        '
        Me.txtStencilNameEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtStencilNameEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtStencilNameEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtStencilNameEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStencilNameEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtStencilNameEdit.Location = New System.Drawing.Point(140, 65)
        Me.txtStencilNameEdit.Margin = New System.Windows.Forms.Padding(0, 0, 0, 6)
        Me.txtStencilNameEdit.MaximumSize = New System.Drawing.Size(493, 40)
        Me.txtStencilNameEdit.MaxLength = 50
        Me.txtStencilNameEdit.MinimumSize = New System.Drawing.Size(133, 15)
        Me.txtStencilNameEdit.Name = "txtStencilNameEdit"
        Me.txtStencilNameEdit.Size = New System.Drawing.Size(155, 20)
        Me.txtStencilNameEdit.TabIndex = 107
        Me.txtStencilNameEdit.Text = "Modelo"
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Roperator)
        Me.Panel4.Controls.Add(Me.Button1)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel4.Location = New System.Drawing.Point(0, 416)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(671, 86)
        Me.Panel4.TabIndex = 102
        '
        'Roperator
        '
        Me.Roperator.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Roperator.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Roperator.FlatAppearance.BorderSize = 0
        Me.Roperator.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.Roperator.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.Roperator.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Roperator.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Roperator.ForeColor = System.Drawing.Color.White
        Me.Roperator.Location = New System.Drawing.Point(71, 12)
        Me.Roperator.Margin = New System.Windows.Forms.Padding(5)
        Me.Roperator.Name = "Roperator"
        Me.Roperator.Size = New System.Drawing.Size(201, 58)
        Me.Roperator.TabIndex = 62
        Me.Roperator.Text = "SAVE"
        Me.Roperator.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.Button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(422, 12)
        Me.Button1.Margin = New System.Windows.Forms.Padding(5)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(211, 58)
        Me.Button1.TabIndex = 98
        Me.Button1.Text = "Return"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'ListView3
        '
        Me.ListView3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListView3.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.ListView3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListView3.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListView3.HideSelection = False
        Me.ListView3.Location = New System.Drawing.Point(182, 441)
        Me.ListView3.Margin = New System.Windows.Forms.Padding(4)
        Me.ListView3.MaximumSize = New System.Drawing.Size(173, 23)
        Me.ListView3.MinimumSize = New System.Drawing.Size(133, 23)
        Me.ListView3.Name = "ListView3"
        Me.ListView3.Size = New System.Drawing.Size(145, 23)
        Me.ListView3.TabIndex = 95
        Me.ListView3.UseCompatibleStateImageBehavior = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(103, 441)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(75, 19)
        Me.Label21.TabIndex = 93
        Me.Label21.Text = "Localidad"
        '
        'editrouterdishform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(683, 574)
        Me.Controls.Add(Me.PanelF)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.ForeColor = System.Drawing.Color.ForestGreen
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "editrouterdishform"
        Me.Text = "editrouterdishformForm"
        Me.PanelF.ResumeLayout(False)
        Me.PanelF.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelF As System.Windows.Forms.Panel
    Friend WithEvents EditDishBtn As System.Windows.Forms.Button
    Friend WithEvents DishToolBtn As System.Windows.Forms.Button
    Friend WithEvents Home As System.Windows.Forms.Button
    Friend WithEvents toolingBtn As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Cicles As System.Windows.Forms.TextBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents DishTool1Btn As System.Windows.Forms.Button
    Friend WithEvents edit As System.Windows.Forms.Label
    Friend WithEvents proyectName As System.Windows.Forms.ComboBox
    Friend WithEvents provedorName As System.Windows.Forms.ComboBox
    Friend WithEvents localidadStencil As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtCommentsStencilEdit As System.Windows.Forms.RichTextBox
    Friend WithEvents txtYPCBEdit As System.Windows.Forms.TextBox
    Friend WithEvents txtNumberPartPCBEdit As System.Windows.Forms.TextBox
    Friend WithEvents DateMakeJob As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtJobStencilEdit As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtXPCBEdit As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtRevStencilEdit As System.Windows.Forms.TextBox
    Friend WithEvents txtStencilNameEdit As System.Windows.Forms.TextBox
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Roperator As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ListView3 As System.Windows.Forms.ListView
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label1 As Label
End Class
