﻿

Public Class inicio

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs)

    End Sub
    Private Sub customizeDesing()
        panelMenuTooling.Visible = False

    End Sub
    Private Sub hideSubMenu()
        panelMenuTooling.Visible = False


    End Sub

    Private Sub showSubMenu(subMenu As Panel)
        If subMenu.Visible = False Then
            hideSubMenu()
            subMenu.Visible = True
        Else
            subMenu.Visible = False
        End If
    End Sub
    Public currentForm As Form = Nothing
    Public Sub openChildForm(childForm As Form)
        If currentForm IsNot Nothing Then currentForm.Close()
        currentForm = childForm
        childForm.TopLevel = False
        childForm.FormBorderStyle = FormBorderStyle.None
        childForm.Dock = DockStyle.Fill
        panelChildForm.Controls.Add(childForm)
        panelChildForm.Tag = childForm
        childForm.BringToFront()
        childForm.Show()
    End Sub

    Private Sub BtnTooling_Click(sender As Object, e As EventArgs) Handles BtnTooling.Click
        showSubMenu(panelMenuTooling)
    End Sub

    Private Sub BtnStencilPanel_Click(sender As Object, e As EventArgs) Handles BtnStencilPanel.Click
        openChildForm(New Stencil)
    End Sub

    Private Sub BtnPalletPanel_Click(sender As Object, e As EventArgs) Handles BtnPalletPanel.Click
        openChildForm(New pallet)
    End Sub

    Private Sub BtnPlateRouterPanel_Click(sender As Object, e As EventArgs) Handles BtnPlateRouterPanel.Click
        openChildForm(New routerdish)
    End Sub
    
    Private Sub BtnManagerUser_Click(sender As Object, e As EventArgs) Handles BtnManagerUser.Click
        If panelMenuTooling.Visible = False Then
            showSubMenu(PanelManagerUser)
            panelMenuTooling.Visible = False
        Else
            showSubMenu(PanelManagerUser)
            panelMenuTooling.Visible = True
        End If
    End Sub

    Private Sub allUser_Click(sender As Object, e As EventArgs) Handles allUser.Click
        openChildForm(New alluser)
    End Sub

    Private Sub addUser_Click(sender As Object, e As EventArgs) Handles addUser.Click
        openChildForm(New adduserform)
    End Sub

    Private Sub Profile_Click(sender As Object, e As EventArgs) Handles dashboard.Click
        openChildForm(New dashboardPanel)
    End Sub

    Private Sub panelChildForm_Paint(sender As Object, e As PaintEventArgs) Handles panelChildForm.Click
        openChildForm(New dashboardPanel)

    End Sub
End Class