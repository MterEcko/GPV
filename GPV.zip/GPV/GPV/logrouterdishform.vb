﻿Public Class logrouterdishform
    Private Sub hideForm()
        PanelF.Visible = False
    End Sub
    Private Sub showForm()

    End Sub
    Private PFormu As Form = Nothing
    Private Sub openPanel(PanelForm As Form)
        If PFormu IsNot Nothing Then PFormu.Close()
        PFormu = PanelForm
        PanelForm.TopLevel = False
        PanelForm.FormBorderStyle = FormBorderStyle.None
        PanelForm.Dock = DockStyle.Fill
        PanelF.Controls.Add(PanelForm)
        PanelF.Tag = PanelForm
        PanelForm.BringToFront()
        PanelForm.Show()
    End Sub

    Private Sub Home_Click(sender As Object, e As EventArgs) Handles Home.Click
        openPanel(New dashboardPanel)
    End Sub

    Private Sub ToolingBtn_Click(sender As Object, e As EventArgs) Handles toolingBtn.Click
        openPanel(New Tooling)
    End Sub

    Private Sub DishToolBtn_Click(sender As Object, e As EventArgs) Handles DishToolBtn.Click, DishTool1Btn.Click
        openPanel(New routerdish)
    End Sub

    Private Sub LogDishBtn_Click(sender As Object, e As EventArgs) Handles LogDishBtn.Click
        openPanel(New logrouterdishform)
    End Sub
    Private Sub textBoxLogStencil_Enter(sender As Object, e As EventArgs)
        If textBoxLogStencil.Text = "Router Dish" Then
            textBoxLogStencil.Text = ""
            textBoxLogStencil.ForeColor = Color.ForestGreen
        End If
    End Sub
    Private Sub textBoxLogStencil_Leave(sender As Object, e As EventArgs)
        If textBoxLogStencil.Text = "" Then
            textBoxLogStencil.Text = "Router Dish"
            textBoxLogStencil.ForeColor = Color.ForestGreen

        End If
    End Sub


End Class
