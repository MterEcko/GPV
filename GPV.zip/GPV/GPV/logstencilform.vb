﻿Public Class logstencilform
    Private Sub hideForm()
        PanelF.Visible = False
    End Sub
    Private Sub showForm()

    End Sub
    Private PFormu As Form = Nothing
    Private Sub openPanel(PanelForm As Form)
        If PFormu IsNot Nothing Then PFormu.Close()
        PFormu = PanelForm
        PanelForm.TopLevel = False
        PanelForm.FormBorderStyle = FormBorderStyle.None
        PanelForm.Dock = DockStyle.Fill
        PanelF.Controls.Add(PanelForm)
        PanelF.Tag = PanelForm
        PanelForm.BringToFront()
        PanelForm.Show()
    End Sub

    Private Sub Home_Click(sender As Object, e As EventArgs) Handles Home.Click
        openPanel(New dashboardPanel)
    End Sub

    Private Sub ToolingBtn_Click(sender As Object, e As EventArgs) Handles toolingBtn.Click
        openPanel(New Tooling)
    End Sub

    Private Sub StencilToolBtn_Click(sender As Object, e As EventArgs) Handles StencilTool1Btn.Click, StencilToolBtn.Click
        openPanel(New Stencil)
    End Sub

    Private Sub logStencilBtn_Click(sender As Object, e As EventArgs) Handles logStencilBtn.Click
        openPanel(New addstencilform)
    End Sub

    Private Sub textBoxLogStencil_Enter(sender As Object, e As EventArgs) Handles textBoxLogStencil.Enter
        If textBoxLogStencil.Text = "Find stencil log" Then
            textBoxLogStencil.Text = ""
            textBoxLogStencil.ForeColor = Color.ForestGreen
        End If
    End Sub
    Private Sub textBoxLogStencil_Leave(sender As Object, e As EventArgs) Handles textBoxLogStencil.Leave
        If textBoxLogStencil.Text = "" Then
            textBoxLogStencil.Text = "Find stencil log"
            textBoxLogStencil.ForeColor = Color.ForestGreen
        End If
    End Sub


End Class