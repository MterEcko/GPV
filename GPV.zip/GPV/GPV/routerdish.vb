﻿Public Class routerdish
    Private Sub hideForm()
        PanelF.Visible = False
    End Sub
    Private Sub showForm()

    End Sub
    Private PFormu As Form = Nothing
    Private Sub openPanel(PanelForm As Form)
        If PFormu IsNot Nothing Then PFormu.Close()
        PFormu = PanelForm
        PanelForm.TopLevel = False
        PanelForm.FormBorderStyle = FormBorderStyle.None
        PanelForm.Dock = DockStyle.Fill
        PanelF.Controls.Add(PanelForm)
        PanelF.Tag = PanelForm
        PanelForm.BringToFront()
        PanelForm.Show()
    End Sub
    Private Sub addRouterDishBtnForm_Click(sender As Object, e As EventArgs) Handles addRouterDishBtnForm.Click
        openPanel(New addrouterdishform)
    End Sub

    Private Sub editRouterDishBtnForm_Click(sender As Object, e As EventArgs) Handles editRouterDishBtnForm.Click
        openPanel(New editrouterdishform)
    End Sub

    Private Sub viewLogRouterDishBtn_Click(sender As Object, e As EventArgs) Handles viewLogRouterDishBtn.Click
        openPanel(New logrouterdishform)
    End Sub

    Private Sub Home_Click(sender As Object, e As EventArgs) Handles Home.Click
        openPanel(New dashboardPanel)
    End Sub

    Private Sub toolingBtn_Click(sender As Object, e As EventArgs) Handles toolingBtn.Click
        openPanel(New Tooling)
    End Sub
    Private Sub DishToolBtn_Click(sender As Object, e As EventArgs) Handles DishToolBtn.Click
        openPanel(New routerdish)
    End Sub
    Private Sub textBoxFindRouterDish_Enter(sender As Object, e As EventArgs)
        If textBoxFindRouterDish.Text = "Find router dish" Then
            textBoxFindRouterDish.Text = ""
            textBoxFindRouterDish.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub textBoxFindRouterDish_Leave(sender As Object, e As EventArgs)
        If textBoxFindRouterDish.Text = "" Then
            textBoxFindRouterDish.Text = "Find router dish"
            textBoxFindRouterDish.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub findRouterDishBtn_Click(sender As Object, e As EventArgs) Handles findRouterDishBtn.Click

    End Sub



End Class