﻿

Public Class FormLogin
    Private Sub Login_Click(sender As Object, e As EventArgs) Handles Login.Click


    End Sub



    Private Sub closelogin_Click(sender As Object, e As EventArgs) Handles closelogin.Click
        Application.Exit()
    End Sub

    Private Sub maxlogin_Click(sender As Object, e As EventArgs) Handles maxlogin.Click

        WindowState = FormWindowState.Maximized
        maxlogin.Visible = False
        restlogin.Visible = True
    End Sub

    Private Sub restlogin_Click(sender As Object, e As EventArgs) Handles restlogin.Click
        WindowState = FormWindowState.Normal
        restlogin.Visible = False
        maxlogin.Visible = True

    End Sub

    Private Sub minuslogin_Click(sender As Object, e As EventArgs) Handles minuslogin.Click
        WindowState = FormWindowState.Minimized
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub
End Class