﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Imports System.IO

Public Class Addstencilform
    Dim bdconexion As New Db()


    Public Sub HideForm()
        PanelF.Visible = False
    End Sub
    Public Sub ShowForm()

    End Sub
    Private PFormu As Form = Nothing
    Private Sub OpenPanel(PanelForm As Form)
        If PFormu IsNot Nothing Then PFormu.Close()
        PFormu = PanelForm
        PanelForm.TopLevel = False
        PanelForm.FormBorderStyle = FormBorderStyle.None
        PanelForm.Dock = DockStyle.Fill
        PanelF.Controls.Add(PanelForm)
        PanelF.Tag = PanelForm
        PanelForm.BringToFront()
        PanelForm.Show()
    End Sub

    Private Sub txtStencilName_Enter(sender As Object, e As EventArgs)
        If txtStencilName.Text = "Stencil Name" Then
            txtStencilName.Text = ""
            txtStencilName.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub txtStencilName_Leave(sender As Object, e As EventArgs)
        If txtStencilName.Text = "" Then
            txtStencilName.Text = "Stencil Name"
            txtStencilName.ForeColor = Color.ForestGreen
        End If
    End Sub
    Private Sub txtNumberPartPCB_Enter(sender As Object, e As EventArgs)
        If txtNumberPartPCB.Text = "Number Part of PCB" Then
            txtNumberPartPCB.Text = ""
            txtNumberPartPCB.ForeColor = Color.ForestGreen
        End If
    End Sub
    Private Sub txtNumberPartPCB_Leave(sender As Object, e As EventArgs)
        If txtNumberPartPCB.Text = "" Then
            txtNumberPartPCB.Text = "Number Part of PCB"
            txtNumberPartPCB.ForeColor = Color.ForestGreen
        End If
    End Sub
    Private Sub txtXPCB_Enter(sender As Object, e As EventArgs)
        If txtXPCB.Text = "X Lengh" Then
            txtXPCB.Text = ""
            txtXPCB.ForeColor = Color.ForestGreen
        End If
    End Sub
    Private Sub txtXPCB_Leave(sender As Object, e As EventArgs)
        If txtXPCB.Text = "" Then
            txtXPCB.Text = "X Lengh"
            txtXPCB.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub txtYPCB_Enter(sender As Object, e As EventArgs)
        If txtYPCB.Text = "Y Width" Then
            txtYPCB.Text = ""
            txtYPCB.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub txtYPCB_Leave(sender As Object, e As EventArgs)
        If txtYPCB.Text = "" Then
            txtYPCB.Text = "Y Width"
            txtYPCB.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub txtRevStencil_Enter(sender As Object, e As EventArgs)
        If txtRevStencil.Text = "Revision" Then
            txtRevStencil.Text = ""
            txtRevStencil.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub txtRevStencil_Leave(sender As Object, e As EventArgs)
        If txtRevStencil.Text = "" Then
            txtRevStencil.Text = "Revision"
            txtRevStencil.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub txtJobStencil_Enter(sender As Object, e As EventArgs)
        If txtJobStencil.Text = "Job" Then
            txtJobStencil.Text = ""
            txtJobStencil.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub txtJobStencil_Leave(sender As Object, e As EventArgs)
        If txtJobStencil.Text = "" Then
            txtJobStencil.Text = "Job"
            txtJobStencil.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub txtCommentsStencil_Enter(sender As Object, e As EventArgs)
        If txtComentariosStencil.Text = "Ingrese comentarios" Then
            txtComentariosStencil.Text = ""
            txtComentariosStencil.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub txtCommentsStencil_Leave(sender As Object, e As EventArgs)
        If txtComentariosStencil.Text = "" Then
            txtComentariosStencil.Text = "Ingrese comentarios"
            txtComentariosStencil.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub addstencilform_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'GPVDataSet.Stencil' Puede moverla o quitarla según sea necesario.
        Me.StencilTableAdapter.Fill(Me.GPVDataSet.Stencil)
        'TODO: This line of code loads data into the 'GPVGROUPDataSet1.Proyects' table. You can move, or remove it, as needed.



    End Sub

    Private Sub Home_Click(sender As Object, e As EventArgs) Handles Home.Click
        openPanel(New dashboardPanel)
    End Sub

    Private Sub ToolingBtn_Click(sender As Object, e As EventArgs) Handles toolingBtn.Click
        openPanel(New Tooling)
    End Sub

    Private Sub StencilToolBtn_Click(sender As Object, e As EventArgs) Handles StencilTool1Btn.Click, StencilToolBtn.Click
        openPanel(New Stencil)
    End Sub

    Private Sub NewStencilBtn_Click(sender As Object, e As EventArgs) Handles NewStencilBtn.Click
        openPanel(New Addstencilform)
    End Sub

    Private Sub PanelF_Paint(sender As Object, e As PaintEventArgs) Handles PanelF.Paint

    End Sub

    Private Sub AddStencilButton_Click_1(sender As Object, e As EventArgs) Handles AddStencilButton.Click

        bdconexion.InsertarStencil(localidadStencil.Text, txtStencilName.Text, txtEnsamble.Text, txtNumberPartPCB.Text,
        txtJobStencil.Text, txtComentariosStencil.Text, txtXPCB.Text, txtYPCB.Text, txtRevStencil.Text,
        txtNum1Tension.Text, txtNum2Tension.Text, txtNum3Tension.Text, txtNum4Tension.Text, txtNum5Tension.Text,
        txtProvedorNameAdd.Text)
    End Sub
End Class