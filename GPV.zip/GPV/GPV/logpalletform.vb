﻿Public Class logpalletform
    Private Sub hideForm()
        PanelF.Visible = False
    End Sub
    Private Sub showForm()

    End Sub
    Private PFormu As Form = Nothing
    Private Sub openPanel(PanelForm As Form)
        If PFormu IsNot Nothing Then PFormu.Close()
        PFormu = PanelForm
        PanelForm.TopLevel = False
        PanelForm.FormBorderStyle = FormBorderStyle.None
        PanelForm.Dock = DockStyle.Fill
        PanelF.Controls.Add(PanelForm)
        PanelF.Tag = PanelForm
        PanelForm.BringToFront()
        PanelForm.Show()
    End Sub

    Private Sub Home_Click(sender As Object, e As EventArgs) Handles Home.Click
        openPanel(New dashboardPanel)
    End Sub

    Private Sub ToolingBtn_Click(sender As Object, e As EventArgs) Handles toolingBtn.Click
        openPanel(New Tooling)
    End Sub

    Private Sub PalletsToolBtn_Click(sender As Object, e As EventArgs) Handles PalletsToolBtn.Click, PalletsTool1Btn.Click
        openPanel(New pallet)
    End Sub

    Private Sub LogPalletsBtn_Click(sender As Object, e As EventArgs) Handles LogPalletsBtn.Click
        openPanel(New logpalletform)
    End Sub
    Private Sub textBoxLogPallet_Enter(sender As Object, e As EventArgs) Handles textBoxLogPallet.Enter
        If textBoxLogPallet.Text = "Find pallet log" Then
            textBoxLogPallet.Text = ""
            textBoxLogPallet.ForeColor = Color.ForestGreen
        End If
    End Sub
    Private Sub textBoxLogPallet_Leave(sender As Object, e As EventArgs) Handles textBoxLogPallet.Leave
        If textBoxLogPallet.Text = "" Then
            textBoxLogPallet.Text = "Find pallet log"
            textBoxLogPallet.ForeColor = Color.ForestGreen
        End If
    End Sub
End Class