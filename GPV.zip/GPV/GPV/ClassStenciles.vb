﻿Public Class ClassStenciles
    Dim IdStencil As Integer
    Dim UbicacionStencil As String
    Dim NombreStencil As String
    Dim EnsambleStencil As String
    Dim PCBStencil As String
    Dim JobStencil As String
    Dim ComentariosStencil As String
    Dim IdProyectoStencil As String
    Dim FechaManufacutaraStencil As String
    Dim XStencil As String
    Dim YStencil As String
    Dim RevStencil As String
    Dim Tension1Stencil As String
    Dim Tension2Stencil As String
    Dim Tension3Stencil As String
    Dim Tension4Stencil As String
    Dim Tension5Stencil As String
    'Dim IdProvedorStencil As String

    'Public Property IdSten() As String
    'Get
    'Return Me.IdStencil
    'End Get
    'Set(value As String)
    'Me.IdStencil = value
    'End Set
    'End Property

    Public Property UbicacionSten() As String
        Get
            Return Me.UbicacionStencil
        End Get
        Set(value As String)
            Me.UbicacionStencil = value
        End Set
    End Property


    Public Property NombreSten() As String
        Get
            Return Me.NombreStencil
        End Get
        Set(value As String)
            Me.NombreStencil = value
        End Set
    End Property

    Public Property EnsambleSten() As String
        Get
            Return Me.EnsambleStencil
        End Get
        Set(value As String)
            Me.EnsambleStencil = value
        End Set
    End Property

    Public Property PCBSten() As String
        Get
            Return Me.PCBStencil
        End Get
        Set(value As String)
            Me.PCBStencil = value
        End Set
    End Property

    'Public Property JobSten() As String
    'Get
    'Return Me.JobStencil
    'End Get
    'Set(value As String)
    'Me.JobStencil = value
    'End Set
    'End Property

    Public Property ComentariosSten() As String
        Get
            Return Me.ComentariosStencil
        End Get
        Set(value As String)
            Me.ComentariosStencil = value
        End Set
    End Property

    'Public Property IdProyectoSten() As String
    'Get
    'Return Me.IdProyectoStencil
    'End Get
    'Set(value As String)
    'Me.IdProyectoStencil = value
    'End Set
    'End Property

    'Public Property FechaManufacutaraSten() As String
    'Get
    'Return Me.FechaManufacutaraStencil
    'End Get
    'Set(value As String)
    'Me.FechaManufacutaraStencil = value
    'End Set
    'End Property

    'Public Property XSten() As String
    'Get
    'Return Me.XStencil
    'End Get
    'Set(value As String)
    'Me.XStencil = value
    'End Set
    'End Property

    'Public Property YSten() As String
    'Get
    'Return Me.YStencil
    'End Get
    'Set(value As String)
    'Me.YStencil = value
    'End Set
    'End Property

    'Public Property RevSten() As String
    'Get
    'Return Me.RevStencil
    'End Get
    'Set(value As String)
    'Me.RevStencil = value
    'End Set
    'End Property

    'Public Property Tension1Sten() As String
    'Get
    'Return Me.Tension1Stencil
    'End Get
    'Set(value As String)
    'Me.Tension1Stencil = value
    '   End Set
    'End Property

    'Public Property Tension2Sten() As String
    'Get
    'Return Me.Tension2Stencil
    'End Get
    'Set(value As String)
    'Me.Tension2Stencil = value
    'End Set
    'End Property

    'Public Property Tension3Sten() As String
    'Get
    'Return Me.Tension3Stencil
    'End Get
    'Set(value As String)
    'Me.Tension3Stencil = value
    'End Set
    'End Property

    'Public Property Tension4Sten() As String
    'Get
    'Return Me.Tension4Stencil
    'End Get
    'Set(value As String)
    'Me.Tension4Stencil = value
    '   End Set
    'End Property

    'Public Property Tension5Sten() As String
    'Get
    'Return Me.Tension5Stencil
    'End Get
    'Set(value As String)
    'Me.Tension5Stencil = value
    'End Set
    'End Property

    'Public Property IdProvedorSten() As String
    'Get
    'Return Me.IdProvedorStencil
    'End Get
    'Set(value As String)
    'Me.IdProvedorStencil = value
    'End Set
    'End Property



End Class
