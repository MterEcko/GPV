﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Imports System.IO


Public Class Stencil
    Dim bdconexion As New Db()
    Public Sub hideStencil()
        PanelF.Visible = False
    End Sub
    Public Sub showStencil()

    End Sub
    Public PFormu As Form = Nothing
    Public Sub openPanel(PanelForm As Form)
        If PFormu IsNot Nothing Then PFormu.Close()
        PFormu = PanelForm
        PanelForm.TopLevel = False
        PanelForm.FormBorderStyle = FormBorderStyle.None
        PanelForm.Dock = DockStyle.Fill
        PanelF.Controls.Add(PanelForm)
        PanelF.Tag = PanelForm
        PanelForm.BringToFront()
        PanelForm.Show()
    End Sub

    Private Sub textBoxFindStencil_Enter(sender As Object, e As EventArgs) Handles textBoxFindStencil.Enter
        If textBoxFindStencil.Text = "Find Stencil" Then
            textBoxFindStencil.Text = ""
            textBoxFindStencil.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub textBoxFindStencil_Leave(sender As Object, e As EventArgs) Handles textBoxFindStencil.Leave
        If textBoxFindStencil.Text = "" Then
            textBoxFindStencil.Text = "Find Stencil"
            textBoxFindStencil.ForeColor = Color.ForestGreen
        End If
    End Sub

    Private Sub addStencilBtnForm_Click(sender As Object, e As EventArgs) Handles addStencilBtnForm.Click
        openPanel(New addstencilform)
    End Sub
    Private Sub editStencilBtnForm_Click(sender As Object, e As EventArgs) Handles editStencilBtnForm.Click

        If (DataGridStencil.IdStencil <> "") Then
            bdconexion.ConsultarStencil(DataGridStencil.IdStencil)
            'txtStencilNameEdit
            openPanel(New editstencilform)
        Else
            MsgBox("Por favor seleccione un stencil")
        End If

    End Sub

    Private Sub viewLogStencilBtn_Click(sender As Object, e As EventArgs) Handles viewLogStencilBtn.Click
        openPanel(New logstencilform)
    End Sub

    Private Sub Home_Click(sender As Object, e As EventArgs) Handles Home.Click
        openPanel(New dashboardPanel)
    End Sub

    Private Sub ToolingBtn_Click(sender As Object, e As EventArgs) Handles Tooling1Btn.Click
        openPanel(New Tooling)
    End Sub

    Private Sub StencilToolBtn_Click(sender As Object, e As EventArgs) Handles StencilToolBtn.Click
        openPanel(New Stencil)
    End Sub


    Private Sub toolingRouterBtn_Click(sender As Object, e As EventArgs) Handles toolingBtn.Click
        openPanel(New Tooling)
    End Sub

    Private Sub Stencil_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'GPVDataSet.Stencil' Puede moverla o quitarla según sea necesario.
        DataGridStencilDate.DataSource = bdconexion.ConsultaStencilDataGridViewer()


    End Sub
    Public Sub DataGridStencil_CellEnter(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridStencilDate.CellEnter
        DataGridStencilDate.SelectionMode = DataGridViewSelectionMode.FullRowSelect

    End Sub

    Public Sub DataGridStencilDate_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridStencilDate.CellContentClick

        Dim RowActual As Int16
        Dim SelectActual As String = 0
        RowActual = DataGridStencilDate.CurrentRow.Index()



        SelectActual = DataGridStencilDate.Item(0, RowActual).Value.ToString

        DataGridStencil.IdStencil = SelectActual
    End Sub
    ' DESACTIVADO TEMPORALMENTE, DESACTIVAR EN DATAGRID VIEW
    Private Sub PanelF_load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub



End Class