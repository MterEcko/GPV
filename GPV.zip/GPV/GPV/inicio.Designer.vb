﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class inicio
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelSideMenu = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.BtnSetup = New System.Windows.Forms.Button()
        Me.PanelManagerUser = New System.Windows.Forms.Panel()
        Me.yourProfile = New System.Windows.Forms.Button()
        Me.addUser = New System.Windows.Forms.Button()
        Me.allUser = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnManagerUser = New System.Windows.Forms.Button()
        Me.panelMenuTooling = New System.Windows.Forms.Panel()
        Me.BtnPlateRouterPanel = New System.Windows.Forms.Button()
        Me.BtnPalletPanel = New System.Windows.Forms.Button()
        Me.BtnStencilPanel = New System.Windows.Forms.Button()
        Me.panelTooling = New System.Windows.Forms.Panel()
        Me.BtnTooling = New System.Windows.Forms.Button()
        Me.PanelDashboard = New System.Windows.Forms.Panel()
        Me.dashboard = New System.Windows.Forms.Button()
        Me.ProfilePicturePanel = New System.Windows.Forms.Panel()
        Me.panelMenuSetup = New System.Windows.Forms.Panel()
        Me.panelChildForm = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureProfile = New System.Windows.Forms.PictureBox()
        Me.panelSideMenu.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.PanelManagerUser.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.panelMenuTooling.SuspendLayout()
        Me.panelTooling.SuspendLayout()
        Me.PanelDashboard.SuspendLayout()
        Me.ProfilePicturePanel.SuspendLayout()
        Me.panelChildForm.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureProfile, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelSideMenu
        '
        Me.panelSideMenu.AutoScroll = True
        Me.panelSideMenu.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.panelSideMenu.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.panelSideMenu.Controls.Add(Me.Panel2)
        Me.panelSideMenu.Controls.Add(Me.PanelManagerUser)
        Me.panelSideMenu.Controls.Add(Me.Panel1)
        Me.panelSideMenu.Controls.Add(Me.panelMenuTooling)
        Me.panelSideMenu.Controls.Add(Me.panelTooling)
        Me.panelSideMenu.Controls.Add(Me.PanelDashboard)
        Me.panelSideMenu.Controls.Add(Me.ProfilePicturePanel)
        Me.panelSideMenu.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelSideMenu.Location = New System.Drawing.Point(0, 0)
        Me.panelSideMenu.Name = "panelSideMenu"
        Me.panelSideMenu.Size = New System.Drawing.Size(200, 691)
        Me.panelSideMenu.TabIndex = 37
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.BtnSetup)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 514)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(200, 61)
        Me.Panel2.TabIndex = 44
        '
        'BtnSetup
        '
        Me.BtnSetup.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.BtnSetup.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnSetup.FlatAppearance.BorderSize = 0
        Me.BtnSetup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.BtnSetup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(182, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(193, Byte), Integer))
        Me.BtnSetup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSetup.Location = New System.Drawing.Point(0, 0)
        Me.BtnSetup.Name = "BtnSetup"
        Me.BtnSetup.Size = New System.Drawing.Size(200, 40)
        Me.BtnSetup.TabIndex = 0
        Me.BtnSetup.Text = "Setup"
        Me.BtnSetup.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnSetup.UseVisualStyleBackColor = False
        '
        'PanelManagerUser
        '
        Me.PanelManagerUser.Controls.Add(Me.yourProfile)
        Me.PanelManagerUser.Controls.Add(Me.addUser)
        Me.PanelManagerUser.Controls.Add(Me.allUser)
        Me.PanelManagerUser.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelManagerUser.Location = New System.Drawing.Point(0, 384)
        Me.PanelManagerUser.Name = "PanelManagerUser"
        Me.PanelManagerUser.Size = New System.Drawing.Size(200, 130)
        Me.PanelManagerUser.TabIndex = 0
        '
        'yourProfile
        '
        Me.yourProfile.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.yourProfile.Dock = System.Windows.Forms.DockStyle.Top
        Me.yourProfile.FlatAppearance.BorderSize = 0
        Me.yourProfile.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.yourProfile.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(182, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(193, Byte), Integer))
        Me.yourProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.yourProfile.Location = New System.Drawing.Point(0, 80)
        Me.yourProfile.Name = "yourProfile"
        Me.yourProfile.Size = New System.Drawing.Size(200, 40)
        Me.yourProfile.TabIndex = 46
        Me.yourProfile.Text = "Your profile"
        Me.yourProfile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.yourProfile.UseVisualStyleBackColor = False
        '
        'addUser
        '
        Me.addUser.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.addUser.Dock = System.Windows.Forms.DockStyle.Top
        Me.addUser.FlatAppearance.BorderSize = 0
        Me.addUser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.addUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(182, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(193, Byte), Integer))
        Me.addUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.addUser.Location = New System.Drawing.Point(0, 40)
        Me.addUser.Name = "addUser"
        Me.addUser.Size = New System.Drawing.Size(200, 40)
        Me.addUser.TabIndex = 45
        Me.addUser.Text = "Add user"
        Me.addUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.addUser.UseVisualStyleBackColor = False
        '
        'allUser
        '
        Me.allUser.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.allUser.Dock = System.Windows.Forms.DockStyle.Top
        Me.allUser.FlatAppearance.BorderSize = 0
        Me.allUser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.allUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(182, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(193, Byte), Integer))
        Me.allUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.allUser.Location = New System.Drawing.Point(0, 0)
        Me.allUser.Name = "allUser"
        Me.allUser.Size = New System.Drawing.Size(200, 40)
        Me.allUser.TabIndex = 44
        Me.allUser.Text = "All user"
        Me.allUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.allUser.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BtnManagerUser)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 334)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(200, 50)
        Me.Panel1.TabIndex = 44
        '
        'BtnManagerUser
        '
        Me.BtnManagerUser.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.BtnManagerUser.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnManagerUser.FlatAppearance.BorderSize = 0
        Me.BtnManagerUser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.BtnManagerUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(182, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(193, Byte), Integer))
        Me.BtnManagerUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnManagerUser.Location = New System.Drawing.Point(0, 0)
        Me.BtnManagerUser.MaximumSize = New System.Drawing.Size(200, 40)
        Me.BtnManagerUser.Name = "BtnManagerUser"
        Me.BtnManagerUser.Size = New System.Drawing.Size(200, 40)
        Me.BtnManagerUser.TabIndex = 39
        Me.BtnManagerUser.Text = "Manager User"
        Me.BtnManagerUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnManagerUser.UseVisualStyleBackColor = False
        '
        'panelMenuTooling
        '
        Me.panelMenuTooling.Controls.Add(Me.BtnPlateRouterPanel)
        Me.panelMenuTooling.Controls.Add(Me.BtnPalletPanel)
        Me.panelMenuTooling.Controls.Add(Me.BtnStencilPanel)
        Me.panelMenuTooling.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelMenuTooling.Location = New System.Drawing.Point(0, 204)
        Me.panelMenuTooling.Name = "panelMenuTooling"
        Me.panelMenuTooling.Size = New System.Drawing.Size(200, 130)
        Me.panelMenuTooling.TabIndex = 38
        '
        'BtnPlateRouterPanel
        '
        Me.BtnPlateRouterPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.BtnPlateRouterPanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnPlateRouterPanel.FlatAppearance.BorderSize = 0
        Me.BtnPlateRouterPanel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.BtnPlateRouterPanel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(182, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(193, Byte), Integer))
        Me.BtnPlateRouterPanel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnPlateRouterPanel.Location = New System.Drawing.Point(0, 83)
        Me.BtnPlateRouterPanel.Name = "BtnPlateRouterPanel"
        Me.BtnPlateRouterPanel.Size = New System.Drawing.Size(200, 40)
        Me.BtnPlateRouterPanel.TabIndex = 43
        Me.BtnPlateRouterPanel.Text = "Plate Router"
        Me.BtnPlateRouterPanel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnPlateRouterPanel.UseVisualStyleBackColor = False
        '
        'BtnPalletPanel
        '
        Me.BtnPalletPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.BtnPalletPanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnPalletPanel.FlatAppearance.BorderSize = 0
        Me.BtnPalletPanel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.BtnPalletPanel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(182, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(193, Byte), Integer))
        Me.BtnPalletPanel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnPalletPanel.Location = New System.Drawing.Point(0, 40)
        Me.BtnPalletPanel.Name = "BtnPalletPanel"
        Me.BtnPalletPanel.Size = New System.Drawing.Size(200, 43)
        Me.BtnPalletPanel.TabIndex = 42
        Me.BtnPalletPanel.Text = "Pallet"
        Me.BtnPalletPanel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnPalletPanel.UseVisualStyleBackColor = False
        '
        'BtnStencilPanel
        '
        Me.BtnStencilPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.BtnStencilPanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnStencilPanel.FlatAppearance.BorderSize = 0
        Me.BtnStencilPanel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.BtnStencilPanel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(182, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(193, Byte), Integer))
        Me.BtnStencilPanel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnStencilPanel.Location = New System.Drawing.Point(0, 0)
        Me.BtnStencilPanel.Name = "BtnStencilPanel"
        Me.BtnStencilPanel.Size = New System.Drawing.Size(200, 40)
        Me.BtnStencilPanel.TabIndex = 41
        Me.BtnStencilPanel.Text = "Stencil"
        Me.BtnStencilPanel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnStencilPanel.UseVisualStyleBackColor = False
        '
        'panelTooling
        '
        Me.panelTooling.Controls.Add(Me.BtnTooling)
        Me.panelTooling.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelTooling.Location = New System.Drawing.Point(0, 154)
        Me.panelTooling.Name = "panelTooling"
        Me.panelTooling.Size = New System.Drawing.Size(200, 50)
        Me.panelTooling.TabIndex = 38
        '
        'BtnTooling
        '
        Me.BtnTooling.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.BtnTooling.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnTooling.FlatAppearance.BorderSize = 0
        Me.BtnTooling.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.BtnTooling.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(182, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(193, Byte), Integer))
        Me.BtnTooling.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTooling.Location = New System.Drawing.Point(0, 0)
        Me.BtnTooling.Name = "BtnTooling"
        Me.BtnTooling.Size = New System.Drawing.Size(200, 40)
        Me.BtnTooling.TabIndex = 40
        Me.BtnTooling.Text = "Tooling"
        Me.BtnTooling.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnTooling.UseVisualStyleBackColor = False
        '
        'PanelDashboard
        '
        Me.PanelDashboard.Controls.Add(Me.dashboard)
        Me.PanelDashboard.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelDashboard.Location = New System.Drawing.Point(0, 111)
        Me.PanelDashboard.Name = "PanelDashboard"
        Me.PanelDashboard.Size = New System.Drawing.Size(200, 43)
        Me.PanelDashboard.TabIndex = 38
        '
        'dashboard
        '
        Me.dashboard.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.dashboard.Cursor = System.Windows.Forms.Cursors.Hand
        Me.dashboard.Dock = System.Windows.Forms.DockStyle.Top
        Me.dashboard.FlatAppearance.BorderSize = 0
        Me.dashboard.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.dashboard.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(182, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(193, Byte), Integer))
        Me.dashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.dashboard.ForeColor = System.Drawing.Color.White
        Me.dashboard.Location = New System.Drawing.Point(0, 0)
        Me.dashboard.Name = "dashboard"
        Me.dashboard.Size = New System.Drawing.Size(200, 40)
        Me.dashboard.TabIndex = 38
        Me.dashboard.Text = "Dashboard"
        Me.dashboard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.dashboard.UseVisualStyleBackColor = False
        '
        'ProfilePicturePanel
        '
        Me.ProfilePicturePanel.Controls.Add(Me.PictureBox2)
        Me.ProfilePicturePanel.Controls.Add(Me.PictureProfile)
        Me.ProfilePicturePanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.ProfilePicturePanel.Location = New System.Drawing.Point(0, 0)
        Me.ProfilePicturePanel.Name = "ProfilePicturePanel"
        Me.ProfilePicturePanel.Size = New System.Drawing.Size(200, 111)
        Me.ProfilePicturePanel.TabIndex = 38
        '
        'panelMenuSetup
        '
        Me.panelMenuSetup.Location = New System.Drawing.Point(163, 498)
        Me.panelMenuSetup.Name = "panelMenuSetup"
        Me.panelMenuSetup.Size = New System.Drawing.Size(200, 57)
        Me.panelMenuSetup.TabIndex = 38
        '
        'panelChildForm
        '
        Me.panelChildForm.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelChildForm.AutoSize = True
        Me.panelChildForm.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.panelChildForm.Controls.Add(Me.Label1)
        Me.panelChildForm.Controls.Add(Me.panelMenuSetup)
        Me.panelChildForm.Location = New System.Drawing.Point(200, 0)
        Me.panelChildForm.MinimumSize = New System.Drawing.Size(714, 0)
        Me.panelChildForm.Name = "panelChildForm"
        Me.panelChildForm.Size = New System.Drawing.Size(784, 691)
        Me.panelChildForm.TabIndex = 38
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(139, 220)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(91, 31)
        Me.Label1.TabIndex = 39
        Me.Label1.Text = "Users"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.GPV.My.Resources.Resources.logo
        Me.PictureBox2.Location = New System.Drawing.Point(3, 3)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(178, 86)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 35
        Me.PictureBox2.TabStop = False
        '
        'PictureProfile
        '
        Me.PictureProfile.BackColor = System.Drawing.Color.White
        Me.PictureProfile.Dock = System.Windows.Forms.DockStyle.Top
        Me.PictureProfile.Location = New System.Drawing.Point(0, 0)
        Me.PictureProfile.Name = "PictureProfile"
        Me.PictureProfile.Size = New System.Drawing.Size(200, 89)
        Me.PictureProfile.TabIndex = 39
        Me.PictureProfile.TabStop = False
        '
        'inicio
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(984, 691)
        Me.Controls.Add(Me.panelSideMenu)
        Me.Controls.Add(Me.panelChildForm)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.ForestGreen
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MinimumSize = New System.Drawing.Size(1000, 726)
        Me.Name = "inicio"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Inicio"
        Me.panelSideMenu.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.PanelManagerUser.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.panelMenuTooling.ResumeLayout(False)
        Me.panelTooling.ResumeLayout(False)
        Me.PanelDashboard.ResumeLayout(False)
        Me.ProfilePicturePanel.ResumeLayout(False)
        Me.panelChildForm.ResumeLayout(False)
        Me.panelChildForm.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureProfile, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents panelSideMenu As System.Windows.Forms.Panel
    Friend WithEvents dashboard As System.Windows.Forms.Button
    Friend WithEvents ProfilePicturePanel As System.Windows.Forms.Panel
    Friend WithEvents PictureProfile As System.Windows.Forms.PictureBox
    Friend WithEvents panelTooling As System.Windows.Forms.Panel
    Friend WithEvents BtnTooling As System.Windows.Forms.Button
    Friend WithEvents PanelDashboard As System.Windows.Forms.Panel
    Friend WithEvents panelMenuTooling As System.Windows.Forms.Panel
    Friend WithEvents BtnPalletPanel As System.Windows.Forms.Button
    Friend WithEvents BtnStencilPanel As System.Windows.Forms.Button
    Friend WithEvents BtnPlateRouterPanel As System.Windows.Forms.Button
    Friend WithEvents allUser As System.Windows.Forms.Button
    Friend WithEvents panelMenuSetup As System.Windows.Forms.Panel
    Friend WithEvents BtnSetup As System.Windows.Forms.Button
    Friend WithEvents panelChildForm As System.Windows.Forms.Panel
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PanelManagerUser As System.Windows.Forms.Panel
    Friend WithEvents BtnManagerUser As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents yourProfile As System.Windows.Forms.Button
    Friend WithEvents addUser As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
