﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Addstencilform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.PanelF = New System.Windows.Forms.Panel()
        Me.NewStencilBtn = New System.Windows.Forms.Button()
        Me.StencilToolBtn = New System.Windows.Forms.Button()
        Me.Home = New System.Windows.Forms.Button()
        Me.toolingBtn = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.txtRevStencil = New System.Windows.Forms.TextBox()
        Me.txtEnsamble = New System.Windows.Forms.TextBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.StencilTool1Btn = New System.Windows.Forms.Button()
        Me.User = New System.Windows.Forms.Label()
        Me.localidadStencil = New System.Windows.Forms.TextBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.AddStencilButton = New System.Windows.Forms.Button()
        Me.ReturnButton = New System.Windows.Forms.Button()
        Me.txtProvedorNameAdd = New System.Windows.Forms.ComboBox()
        Me.StencilBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GPVDataSet = New GPV.GPVDataSet()
        Me.proyectName = New System.Windows.Forms.ComboBox()
        Me.txtNum1Tension = New System.Windows.Forms.TextBox()
        Me.txtNum5Tension = New System.Windows.Forms.TextBox()
        Me.txtNum2Tension = New System.Windows.Forms.TextBox()
        Me.txtNum4Tension = New System.Windows.Forms.TextBox()
        Me.txtNum3Tension = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtComentariosStencil = New System.Windows.Forms.RichTextBox()
        Me.txtYPCB = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtNumberPartPCB = New System.Windows.Forms.TextBox()
        Me.DateMakeJobAdd = New System.Windows.Forms.DateTimePicker()
        Me.txtJobStencil = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtXPCB = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.txtStencilName = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.StencilTableAdapter = New GPV.GPVDataSetTableAdapters.StencilTableAdapter()
        Me.PanelF.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.StencilBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GPVDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PanelF
        '
        Me.PanelF.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.PanelF.Controls.Add(Me.NewStencilBtn)
        Me.PanelF.Controls.Add(Me.StencilToolBtn)
        Me.PanelF.Controls.Add(Me.Home)
        Me.PanelF.Controls.Add(Me.toolingBtn)
        Me.PanelF.Controls.Add(Me.Panel1)
        Me.PanelF.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelF.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PanelF.ForeColor = System.Drawing.Color.ForestGreen
        Me.PanelF.Location = New System.Drawing.Point(0, 0)
        Me.PanelF.Name = "PanelF"
        Me.PanelF.Size = New System.Drawing.Size(683, 574)
        Me.PanelF.TabIndex = 40
        '
        'NewStencilBtn
        '
        Me.NewStencilBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.NewStencilBtn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.NewStencilBtn.FlatAppearance.BorderSize = 3
        Me.NewStencilBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.NewStencilBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.NewStencilBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NewStencilBtn.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.NewStencilBtn.ForeColor = System.Drawing.Color.ForestGreen
        Me.NewStencilBtn.Location = New System.Drawing.Point(340, 12)
        Me.NewStencilBtn.Name = "NewStencilBtn"
        Me.NewStencilBtn.Size = New System.Drawing.Size(122, 38)
        Me.NewStencilBtn.TabIndex = 120
        Me.NewStencilBtn.Text = "New Stencil"
        Me.NewStencilBtn.UseVisualStyleBackColor = False
        '
        'StencilToolBtn
        '
        Me.StencilToolBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.StencilToolBtn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.StencilToolBtn.FlatAppearance.BorderSize = 3
        Me.StencilToolBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.StencilToolBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.StencilToolBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.StencilToolBtn.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.StencilToolBtn.ForeColor = System.Drawing.Color.ForestGreen
        Me.StencilToolBtn.Location = New System.Drawing.Point(231, 12)
        Me.StencilToolBtn.Name = "StencilToolBtn"
        Me.StencilToolBtn.Size = New System.Drawing.Size(103, 38)
        Me.StencilToolBtn.TabIndex = 119
        Me.StencilToolBtn.Text = "Stencils"
        Me.StencilToolBtn.UseVisualStyleBackColor = False
        '
        'Home
        '
        Me.Home.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.Home.FlatAppearance.BorderSize = 3
        Me.Home.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Home.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.Home.ForeColor = System.Drawing.Color.ForestGreen
        Me.Home.Location = New System.Drawing.Point(13, 12)
        Me.Home.Name = "Home"
        Me.Home.Size = New System.Drawing.Size(103, 38)
        Me.Home.TabIndex = 118
        Me.Home.Text = "Home"
        Me.Home.UseVisualStyleBackColor = False
        '
        'toolingBtn
        '
        Me.toolingBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.toolingBtn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.toolingBtn.FlatAppearance.BorderSize = 3
        Me.toolingBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.toolingBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.toolingBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.toolingBtn.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.toolingBtn.ForeColor = System.Drawing.Color.ForestGreen
        Me.toolingBtn.Location = New System.Drawing.Point(122, 12)
        Me.toolingBtn.Name = "toolingBtn"
        Me.toolingBtn.Size = New System.Drawing.Size(103, 38)
        Me.toolingBtn.TabIndex = 117
        Me.toolingBtn.Text = "Tooling"
        Me.toolingBtn.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.CheckBox2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.CheckBox1)
        Me.Panel1.Controls.Add(Me.txtRevStencil)
        Me.Panel1.Controls.Add(Me.txtEnsamble)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.localidadStencil)
        Me.Panel1.Controls.Add(Me.Panel4)
        Me.Panel1.Controls.Add(Me.txtProvedorNameAdd)
        Me.Panel1.Controls.Add(Me.proyectName)
        Me.Panel1.Controls.Add(Me.txtNum1Tension)
        Me.Panel1.Controls.Add(Me.txtNum5Tension)
        Me.Panel1.Controls.Add(Me.txtNum2Tension)
        Me.Panel1.Controls.Add(Me.txtNum4Tension)
        Me.Panel1.Controls.Add(Me.txtNum3Tension)
        Me.Panel1.Controls.Add(Me.Label22)
        Me.Panel1.Controls.Add(Me.txtComentariosStencil)
        Me.Panel1.Controls.Add(Me.txtYPCB)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.txtNumberPartPCB)
        Me.Panel1.Controls.Add(Me.DateMakeJobAdd)
        Me.Panel1.Controls.Add(Me.txtJobStencil)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.ListView1)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.txtXPCB)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.DateTimePicker2)
        Me.Panel1.Controls.Add(Me.txtStencilName)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel1.Location = New System.Drawing.Point(5, 58)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(20)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(673, 504)
        Me.Panel1.TabIndex = 104
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(211, 391)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(48, 23)
        Me.CheckBox2.TabIndex = 142
        Me.CheckBox2.Text = "No"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(58, 392)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(63, 19)
        Me.Label1.TabIndex = 141
        Me.Label1.Text = "Danado"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(139, 392)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(41, 23)
        Me.CheckBox1.TabIndex = 140
        Me.CheckBox1.Text = "Si"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'txtRevStencil
        '
        Me.txtRevStencil.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtRevStencil.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtRevStencil.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtRevStencil.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRevStencil.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtRevStencil.Location = New System.Drawing.Point(140, 311)
        Me.txtRevStencil.Margin = New System.Windows.Forms.Padding(5)
        Me.txtRevStencil.MaximumSize = New System.Drawing.Size(192, 40)
        Me.txtRevStencil.MaxLength = 30
        Me.txtRevStencil.MinimumSize = New System.Drawing.Size(155, 15)
        Me.txtRevStencil.Name = "txtRevStencil"
        Me.txtRevStencil.Size = New System.Drawing.Size(155, 20)
        Me.txtRevStencil.TabIndex = 121
        Me.txtRevStencil.Text = "Revision"
        '
        'txtEnsamble
        '
        Me.txtEnsamble.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtEnsamble.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtEnsamble.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtEnsamble.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEnsamble.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtEnsamble.Location = New System.Drawing.Point(140, 92)
        Me.txtEnsamble.Margin = New System.Windows.Forms.Padding(5)
        Me.txtEnsamble.MaximumSize = New System.Drawing.Size(192, 40)
        Me.txtEnsamble.MaxLength = 50
        Me.txtEnsamble.MinimumSize = New System.Drawing.Size(133, 15)
        Me.txtEnsamble.Name = "txtEnsamble"
        Me.txtEnsamble.Size = New System.Drawing.Size(192, 20)
        Me.txtEnsamble.TabIndex = 139
        Me.txtEnsamble.Text = "Number Part of Ensamble"
        '
        'Panel3
        '
        Me.Panel3.AutoSize = True
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Panel3.Controls.Add(Me.StencilTool1Btn)
        Me.Panel3.Controls.Add(Me.User)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(10, 3, 10, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(671, 47)
        Me.Panel3.TabIndex = 133
        '
        'StencilTool1Btn
        '
        Me.StencilTool1Btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.StencilTool1Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.StencilTool1Btn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.StencilTool1Btn.FlatAppearance.BorderSize = 3
        Me.StencilTool1Btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.StencilTool1Btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.StencilTool1Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.StencilTool1Btn.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.StencilTool1Btn.ForeColor = System.Drawing.Color.ForestGreen
        Me.StencilTool1Btn.Location = New System.Drawing.Point(511, 6)
        Me.StencilTool1Btn.Name = "StencilTool1Btn"
        Me.StencilTool1Btn.Size = New System.Drawing.Size(156, 38)
        Me.StencilTool1Btn.TabIndex = 111
        Me.StencilTool1Btn.Text = "Stencils"
        Me.StencilTool1Btn.UseVisualStyleBackColor = False
        '
        'User
        '
        Me.User.AutoSize = True
        Me.User.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.User.ForeColor = System.Drawing.Color.White
        Me.User.Location = New System.Drawing.Point(31, 14)
        Me.User.Name = "User"
        Me.User.Size = New System.Drawing.Size(91, 19)
        Me.User.TabIndex = 109
        Me.User.Text = "New Stencil"
        '
        'localidadStencil
        '
        Me.localidadStencil.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.localidadStencil.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.localidadStencil.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.localidadStencil.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.localidadStencil.ForeColor = System.Drawing.Color.ForestGreen
        Me.localidadStencil.Location = New System.Drawing.Point(139, 364)
        Me.localidadStencil.Margin = New System.Windows.Forms.Padding(5)
        Me.localidadStencil.MaximumSize = New System.Drawing.Size(192, 40)
        Me.localidadStencil.MaxLength = 50
        Me.localidadStencil.MinimumSize = New System.Drawing.Size(133, 15)
        Me.localidadStencil.Name = "localidadStencil"
        Me.localidadStencil.Size = New System.Drawing.Size(133, 20)
        Me.localidadStencil.TabIndex = 132
        Me.localidadStencil.Text = "Localidad"
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.AddStencilButton)
        Me.Panel4.Controls.Add(Me.ReturnButton)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel4.Location = New System.Drawing.Point(0, 427)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(671, 75)
        Me.Panel4.TabIndex = 131
        '
        'AddStencilButton
        '
        Me.AddStencilButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.AddStencilButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.AddStencilButton.FlatAppearance.BorderSize = 0
        Me.AddStencilButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.AddStencilButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.AddStencilButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.AddStencilButton.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddStencilButton.ForeColor = System.Drawing.Color.White
        Me.AddStencilButton.Location = New System.Drawing.Point(71, 12)
        Me.AddStencilButton.Margin = New System.Windows.Forms.Padding(0)
        Me.AddStencilButton.Name = "AddStencilButton"
        Me.AddStencilButton.Size = New System.Drawing.Size(240, 58)
        Me.AddStencilButton.TabIndex = 62
        Me.AddStencilButton.Text = "SAVE"
        Me.AddStencilButton.UseVisualStyleBackColor = False
        '
        'ReturnButton
        '
        Me.ReturnButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ReturnButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.ReturnButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.ReturnButton.FlatAppearance.BorderSize = 0
        Me.ReturnButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.ReturnButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.ReturnButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ReturnButton.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReturnButton.ForeColor = System.Drawing.Color.White
        Me.ReturnButton.Location = New System.Drawing.Point(337, 12)
        Me.ReturnButton.Margin = New System.Windows.Forms.Padding(5)
        Me.ReturnButton.Name = "ReturnButton"
        Me.ReturnButton.Size = New System.Drawing.Size(240, 58)
        Me.ReturnButton.TabIndex = 98
        Me.ReturnButton.Text = "Return"
        Me.ReturnButton.UseVisualStyleBackColor = False
        '
        'txtProvedorNameAdd
        '
        Me.txtProvedorNameAdd.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtProvedorNameAdd.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtProvedorNameAdd.DataSource = Me.StencilBindingSource
        Me.txtProvedorNameAdd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtProvedorNameAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtProvedorNameAdd.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.txtProvedorNameAdd.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtProvedorNameAdd.FormattingEnabled = True
        Me.txtProvedorNameAdd.Location = New System.Drawing.Point(140, 276)
        Me.txtProvedorNameAdd.Margin = New System.Windows.Forms.Padding(0)
        Me.txtProvedorNameAdd.MaximumSize = New System.Drawing.Size(155, 0)
        Me.txtProvedorNameAdd.Name = "txtProvedorNameAdd"
        Me.txtProvedorNameAdd.Size = New System.Drawing.Size(154, 27)
        Me.txtProvedorNameAdd.TabIndex = 130
        '
        'StencilBindingSource
        '
        Me.StencilBindingSource.DataMember = "Stencil"
        Me.StencilBindingSource.DataSource = Me.GPVDataSet
        '
        'GPVDataSet
        '
        Me.GPVDataSet.DataSetName = "GPVDataSet"
        Me.GPVDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'proyectName
        '
        Me.proyectName.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.proyectName.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.proyectName.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.proyectName.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.proyectName.ForeColor = System.Drawing.Color.ForestGreen
        Me.proyectName.FormattingEnabled = True
        Me.proyectName.Items.AddRange(New Object() {"Provedor", "Prueba"})
        Me.proyectName.Location = New System.Drawing.Point(140, 146)
        Me.proyectName.Margin = New System.Windows.Forms.Padding(0)
        Me.proyectName.MaximumSize = New System.Drawing.Size(155, 0)
        Me.proyectName.Name = "proyectName"
        Me.proyectName.Size = New System.Drawing.Size(154, 27)
        Me.proyectName.TabIndex = 108
        Me.proyectName.Tag = "Proyecto"
        Me.proyectName.Text = "Proyecto"
        '
        'txtNum1Tension
        '
        Me.txtNum1Tension.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNum1Tension.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.txtNum1Tension.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtNum1Tension.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNum1Tension.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtNum1Tension.Location = New System.Drawing.Point(412, 103)
        Me.txtNum1Tension.Margin = New System.Windows.Forms.Padding(5)
        Me.txtNum1Tension.MaximumSize = New System.Drawing.Size(73, 20)
        Me.txtNum1Tension.MinimumSize = New System.Drawing.Size(27, 20)
        Me.txtNum1Tension.Name = "txtNum1Tension"
        Me.txtNum1Tension.Size = New System.Drawing.Size(73, 20)
        Me.txtNum1Tension.TabIndex = 104
        Me.txtNum1Tension.Text = "Value"
        '
        'txtNum5Tension
        '
        Me.txtNum5Tension.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNum5Tension.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.txtNum5Tension.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtNum5Tension.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNum5Tension.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtNum5Tension.Location = New System.Drawing.Point(478, 170)
        Me.txtNum5Tension.Margin = New System.Windows.Forms.Padding(5)
        Me.txtNum5Tension.MaximumSize = New System.Drawing.Size(73, 20)
        Me.txtNum5Tension.MinimumSize = New System.Drawing.Size(67, 20)
        Me.txtNum5Tension.Name = "txtNum5Tension"
        Me.txtNum5Tension.Size = New System.Drawing.Size(73, 20)
        Me.txtNum5Tension.TabIndex = 129
        Me.txtNum5Tension.Text = "Value 5"
        '
        'txtNum2Tension
        '
        Me.txtNum2Tension.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNum2Tension.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.txtNum2Tension.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtNum2Tension.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNum2Tension.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtNum2Tension.Location = New System.Drawing.Point(538, 103)
        Me.txtNum2Tension.Margin = New System.Windows.Forms.Padding(5)
        Me.txtNum2Tension.MaximumSize = New System.Drawing.Size(73, 20)
        Me.txtNum2Tension.MinimumSize = New System.Drawing.Size(27, 20)
        Me.txtNum2Tension.Name = "txtNum2Tension"
        Me.txtNum2Tension.Size = New System.Drawing.Size(73, 20)
        Me.txtNum2Tension.TabIndex = 105
        Me.txtNum2Tension.Text = "Value 2"
        '
        'txtNum4Tension
        '
        Me.txtNum4Tension.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNum4Tension.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.txtNum4Tension.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtNum4Tension.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNum4Tension.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtNum4Tension.Location = New System.Drawing.Point(538, 240)
        Me.txtNum4Tension.Margin = New System.Windows.Forms.Padding(5)
        Me.txtNum4Tension.MaximumSize = New System.Drawing.Size(73, 20)
        Me.txtNum4Tension.MinimumSize = New System.Drawing.Size(27, 20)
        Me.txtNum4Tension.Name = "txtNum4Tension"
        Me.txtNum4Tension.Size = New System.Drawing.Size(73, 20)
        Me.txtNum4Tension.TabIndex = 106
        Me.txtNum4Tension.Text = "Value 4"
        '
        'txtNum3Tension
        '
        Me.txtNum3Tension.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNum3Tension.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.txtNum3Tension.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtNum3Tension.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNum3Tension.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtNum3Tension.Location = New System.Drawing.Point(412, 240)
        Me.txtNum3Tension.Margin = New System.Windows.Forms.Padding(5)
        Me.txtNum3Tension.MaximumSize = New System.Drawing.Size(73, 20)
        Me.txtNum3Tension.MinimumSize = New System.Drawing.Size(27, 20)
        Me.txtNum3Tension.Name = "txtNum3Tension"
        Me.txtNum3Tension.Size = New System.Drawing.Size(73, 20)
        Me.txtNum3Tension.TabIndex = 107
        Me.txtNum3Tension.Text = "Value 3"
        '
        'Label22
        '
        Me.Label22.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(387, 292)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(113, 23)
        Me.Label22.TabIndex = 126
        Me.Label22.Text = "Comentarios"
        '
        'txtComentariosStencil
        '
        Me.txtComentariosStencil.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtComentariosStencil.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtComentariosStencil.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtComentariosStencil.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtComentariosStencil.Location = New System.Drawing.Point(391, 315)
        Me.txtComentariosStencil.Margin = New System.Windows.Forms.Padding(0)
        Me.txtComentariosStencil.MaximumSize = New System.Drawing.Size(467, 172)
        Me.txtComentariosStencil.MinimumSize = New System.Drawing.Size(213, 86)
        Me.txtComentariosStencil.Name = "txtComentariosStencil"
        Me.txtComentariosStencil.Size = New System.Drawing.Size(220, 86)
        Me.txtComentariosStencil.TabIndex = 127
        Me.txtComentariosStencil.Text = "Ingrese comentarios"
        '
        'txtYPCB
        '
        Me.txtYPCB.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtYPCB.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtYPCB.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtYPCB.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtYPCB.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtYPCB.Location = New System.Drawing.Point(237, 248)
        Me.txtYPCB.Margin = New System.Windows.Forms.Padding(5)
        Me.txtYPCB.MaximumSize = New System.Drawing.Size(93, 40)
        Me.txtYPCB.MaxLength = 30
        Me.txtYPCB.MinimumSize = New System.Drawing.Size(40, 15)
        Me.txtYPCB.Name = "txtYPCB"
        Me.txtYPCB.Size = New System.Drawing.Size(58, 20)
        Me.txtYPCB.TabIndex = 128
        Me.txtYPCB.Text = "Y Width"
        '
        'Label14
        '
        Me.Label14.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(400, 58)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.MaximumSize = New System.Drawing.Size(181, 31)
        Me.Label14.MinimumSize = New System.Drawing.Size(181, 31)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(181, 31)
        Me.Label14.TabIndex = 119
        Me.Label14.Text = "Tension inicial"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtNumberPartPCB
        '
        Me.txtNumberPartPCB.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNumberPartPCB.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtNumberPartPCB.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtNumberPartPCB.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNumberPartPCB.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtNumberPartPCB.Location = New System.Drawing.Point(140, 118)
        Me.txtNumberPartPCB.Margin = New System.Windows.Forms.Padding(5)
        Me.txtNumberPartPCB.MaximumSize = New System.Drawing.Size(192, 40)
        Me.txtNumberPartPCB.MaxLength = 50
        Me.txtNumberPartPCB.MinimumSize = New System.Drawing.Size(133, 15)
        Me.txtNumberPartPCB.Name = "txtNumberPartPCB"
        Me.txtNumberPartPCB.Size = New System.Drawing.Size(155, 20)
        Me.txtNumberPartPCB.TabIndex = 110
        Me.txtNumberPartPCB.Text = "Number Part of PCB"
        '
        'DateMakeJobAdd
        '
        Me.DateMakeJobAdd.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DateMakeJobAdd.CalendarForeColor = System.Drawing.Color.ForestGreen
        Me.DateMakeJobAdd.CalendarMonthBackground = System.Drawing.Color.ForestGreen
        Me.DateMakeJobAdd.CalendarTitleBackColor = System.Drawing.Color.ForestGreen
        Me.DateMakeJobAdd.CalendarTitleForeColor = System.Drawing.Color.ForestGreen
        Me.DateMakeJobAdd.CalendarTrailingForeColor = System.Drawing.Color.ForestGreen
        Me.DateMakeJobAdd.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateMakeJobAdd.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateMakeJobAdd.Location = New System.Drawing.Point(140, 180)
        Me.DateMakeJobAdd.Margin = New System.Windows.Forms.Padding(4)
        Me.DateMakeJobAdd.MaxDate = New Date(2099, 12, 31, 0, 0, 0, 0)
        Me.DateMakeJobAdd.MaximumSize = New System.Drawing.Size(155, 27)
        Me.DateMakeJobAdd.MinDate = New Date(2010, 1, 1, 0, 0, 0, 0)
        Me.DateMakeJobAdd.MinimumSize = New System.Drawing.Size(132, 4)
        Me.DateMakeJobAdd.Name = "DateMakeJobAdd"
        Me.DateMakeJobAdd.Size = New System.Drawing.Size(155, 27)
        Me.DateMakeJobAdd.TabIndex = 115
        '
        'txtJobStencil
        '
        Me.txtJobStencil.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtJobStencil.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtJobStencil.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtJobStencil.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtJobStencil.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtJobStencil.Location = New System.Drawing.Point(139, 337)
        Me.txtJobStencil.Margin = New System.Windows.Forms.Padding(5)
        Me.txtJobStencil.MaximumSize = New System.Drawing.Size(192, 40)
        Me.txtJobStencil.MaxLength = 30
        Me.txtJobStencil.MinimumSize = New System.Drawing.Size(133, 15)
        Me.txtJobStencil.Name = "txtJobStencil"
        Me.txtJobStencil.Size = New System.Drawing.Size(155, 20)
        Me.txtJobStencil.TabIndex = 123
        Me.txtJobStencil.Text = "Job"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(7, 184)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(130, 19)
        Me.Label10.TabIndex = 114
        Me.Label10.Text = "Fecha fabricacion"
        '
        'ListView1
        '
        Me.ListView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListView1.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.ListView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListView1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListView1.HideSelection = False
        Me.ListView1.Location = New System.Drawing.Point(139, 296)
        Me.ListView1.Margin = New System.Windows.Forms.Padding(4)
        Me.ListView1.MaximumSize = New System.Drawing.Size(173, 23)
        Me.ListView1.MinimumSize = New System.Drawing.Size(133, 23)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(138, 23)
        Me.ListView1.TabIndex = 118
        Me.ListView1.UseCompatibleStateImageBehavior = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(7, 216)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(128, 19)
        Me.Label7.TabIndex = 111
        Me.Label7.Text = "Fecha de ingreso"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(58, 280)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(73, 19)
        Me.Label9.TabIndex = 113
        Me.Label9.Text = "Provedor"
        '
        'txtXPCB
        '
        Me.txtXPCB.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtXPCB.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtXPCB.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtXPCB.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtXPCB.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtXPCB.Location = New System.Drawing.Point(140, 248)
        Me.txtXPCB.Margin = New System.Windows.Forms.Padding(5)
        Me.txtXPCB.MaximumSize = New System.Drawing.Size(93, 40)
        Me.txtXPCB.MaxLength = 30
        Me.txtXPCB.MinimumSize = New System.Drawing.Size(40, 15)
        Me.txtXPCB.Name = "txtXPCB"
        Me.txtXPCB.Size = New System.Drawing.Size(63, 20)
        Me.txtXPCB.TabIndex = 117
        Me.txtXPCB.Text = "X Lengh"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(65, 249)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(66, 19)
        Me.Label8.TabIndex = 112
        Me.Label8.Text = "Medidas"
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DateTimePicker2.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.DateTimePicker2.CalendarTitleForeColor = System.Drawing.Color.ForestGreen
        Me.DateTimePicker2.CalendarTrailingForeColor = System.Drawing.Color.ForestGreen
        Me.DateTimePicker2.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateTimePicker2.Location = New System.Drawing.Point(140, 214)
        Me.DateTimePicker2.Margin = New System.Windows.Forms.Padding(4)
        Me.DateTimePicker2.MaximumSize = New System.Drawing.Size(155, 27)
        Me.DateTimePicker2.MinimumSize = New System.Drawing.Size(132, 4)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(155, 27)
        Me.DateTimePicker2.TabIndex = 116
        '
        'txtStencilName
        '
        Me.txtStencilName.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtStencilName.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtStencilName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtStencilName.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStencilName.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtStencilName.Location = New System.Drawing.Point(140, 65)
        Me.txtStencilName.Margin = New System.Windows.Forms.Padding(0, 0, 0, 6)
        Me.txtStencilName.MaximumSize = New System.Drawing.Size(192, 40)
        Me.txtStencilName.MaxLength = 50
        Me.txtStencilName.MinimumSize = New System.Drawing.Size(133, 15)
        Me.txtStencilName.Name = "txtStencilName"
        Me.txtStencilName.Size = New System.Drawing.Size(155, 20)
        Me.txtStencilName.TabIndex = 109
        Me.txtStencilName.Text = "Stencil Name"
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.Image = Global.GPV.My.Resources.Resources.frame_stencil_tension
        Me.PictureBox1.Location = New System.Drawing.Point(378, 92)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox1.MaximumSize = New System.Drawing.Size(520, 290)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(269, 185)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 120
        Me.PictureBox1.TabStop = False
        '
        'StencilTableAdapter
        '
        Me.StencilTableAdapter.ClearBeforeFill = True
        '
        'addstencilform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(683, 574)
        Me.Controls.Add(Me.PanelF)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.ForestGreen
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MinimizeBox = False
        Me.Name = "addstencilform"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "addstencilform"
        Me.PanelF.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        CType(Me.StencilBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GPVDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelF As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtProvedorNameAdd As System.Windows.Forms.ComboBox
    Friend WithEvents proyectName As System.Windows.Forms.ComboBox
    Friend WithEvents txtNum1Tension As System.Windows.Forms.TextBox
    Friend WithEvents txtNum5Tension As System.Windows.Forms.TextBox
    Friend WithEvents txtNum2Tension As System.Windows.Forms.TextBox
    Friend WithEvents txtNum4Tension As System.Windows.Forms.TextBox
    Friend WithEvents txtNum3Tension As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtComentariosStencil As System.Windows.Forms.RichTextBox
    Friend WithEvents txtYPCB As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtNumberPartPCB As System.Windows.Forms.TextBox
    Friend WithEvents DateMakeJobAdd As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtJobStencil As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtXPCB As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtRevStencil As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtStencilName As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents StencilToolBtn As System.Windows.Forms.Button
    Friend WithEvents Home As System.Windows.Forms.Button
    Friend WithEvents toolingBtn As System.Windows.Forms.Button
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents AddStencilButton As System.Windows.Forms.Button
    Friend WithEvents ReturnButton As System.Windows.Forms.Button
    Friend WithEvents localidadStencil As System.Windows.Forms.TextBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents StencilTool1Btn As System.Windows.Forms.Button
    Friend WithEvents User As System.Windows.Forms.Label
    Friend WithEvents NewStencilBtn As System.Windows.Forms.Button
    Friend WithEvents txtEnsamble As TextBox
    Friend WithEvents GPVDataSet As GPVDataSet
    Friend WithEvents StencilBindingSource As BindingSource
    Friend WithEvents StencilTableAdapter As GPVDataSetTableAdapters.StencilTableAdapter
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents Label1 As Label
    Friend WithEvents CheckBox1 As CheckBox
End Class
