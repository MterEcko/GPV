﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Imports System.IO
Imports System.Linq
Imports System.Threading.Tasks
Imports System.Text


Public Class Db
    Dim Conexiones As New SqlConnection()
    Dim Direccion As ConnectionStringSettings
    Dim Comando As SqlCommand

    Public Table As New DataTable()
    'Dim Id As New DataGridStencil()

    Sub Conectar()
        Direccion = ConfigurationManager.ConnectionStrings("ConexionPrueba")
        Conexiones.ConnectionString = Direccion.ConnectionString
        Conexiones.Open()

        'MsgBox("Conectado")

    End Sub

    Sub Desconectar()

        Conexiones.Close()
    End Sub


    Sub InsertarStencil(Localidad As String, NombreStencil As String, Ensamble As String, PartPCB As String, Job As String, Comentarios As String,
                        X As String, Y As String, Rev As String, Tension1 As String, Tension2 As String, Tension3 As String, Tension4 As String,
                        Tension5 As String, Provedor As String)


        Conectar()

        Comando = New SqlCommand("Insert Into Stencil (Ubicacion,Stencil,Ensamble,PCB,JOB,Comentarios,Condicion,Dano,Id_Proyecto,DateManufacture,DataRun,X ,Y,Revision,TensionValue1,TensionValue2,TensionValue3,TensionValue4,TensionValue5,Id_Provedor) Values('" + Localidad + "','" + NombreStencil + "',
        '" + Ensamble + "', '" + PartPCB + "', '" + Job + "',
        '" + Comentarios + "','Condicion', 'Dano', '1', '15/05/2000', '15/05/2000',
        '1','1','" + Rev + "',
        '10', '10', '10',
        '10', '10', '10')", Conexiones)
        'Comando = New SqlCommand("Insert Into Stencil (Ubicacion,Stencil,Ensamble,PCB,JOB,Comentarios,Condicion,Dano,Id_Proyecto,DateManufacture,DataRun,X
        '                           ,Y,Revision,TensionValue1,TensionValue2,TensionValue3,TensionValue4,TensionValue5,Id_Provedor) 
        ' Values('" + Localidad + "','" + NombreStencil + "',
        '" + Ensamble + "', '" + PartPCB + "', '" + Job + "',
        '" + Comentarios + "','Condicion', 'Dano', '1', '15/05/2000', '15/05/2000',
        '" + X + "','" + Y + "','" + Rev + "',
        '" + Tension1 + "', '" + Tension2 + "', '" + Tension3 + "',
        '" + Tension4 + "', '" + Tension5 + "', '" + Provedor + "')", Conexiones)



        Comando.ExecuteNonQuery()

        Desconectar()

        'proyectName.SelectedValue = Dr("Proyect")
        'DateMakeJob.Norecuerdo = Dr("DateManufacture")
        'DateManufactory.Norecoruedo = Dr("DataRun")
        'Dim Proyecto = Dr("Proyect").ToString()
        ''txtNumberPartPCBEdit.Text = Proyecto

    End Sub

    Sub ActualizarStencil()
        Conectar()
        'Comando = New SqlCommand("Update Stencil Set Stencil='" + txtStencilNameEdit.Text + "', Ensamble='" + txtEnsambleEdit.Text + "'
        ', X='" + txtXPCBEdit.Text + "', Y='" + txtYPCBEdit.Text + "', Revision='" + txtRevStencilEdit.Text + "'
        ',JOB='" + txtJobStencilEdit.Text + "', Ubicacion='" + localidadStencil.Text + "', TensionValue1='" + txtNum1TensionEdit.Text + "'
        ',TensionValue2='" + txtNum2TensionEdit.Text + "', TensionValue3='" + txtNum3TensionEdit.Text + "'
        ',TensionValue4='" + txtNum4TensionEdit.Text + "', TensionValue5='" + txtNum5TensionEdit.Text + "'
        ',Comentarios='" + txtCommentsStencilEdit.Text + "', PCB='" + txtNumberPartPCBEdit.Text + "',
        ',Provedor='" + provedorNameEdit.Text + "' WHERE Ubicacion='" + localidadStencil.Text + "'")

        Comando.ExecuteNonQuery()

        Desconectar()

        'proyectName.SelectedValue = Dr("Proyect")
        'DateMakeJob.Norecuerdo = Dr("DateManufacture")
        'DateManufactory.Norecoruedo = Dr("DataRun")
        'Dim Proyecto = Dr("Proyect").ToString()
        ''txtNumberPartPCBEdit.Text = Proyecto

    End Sub
    Sub ConsultarStencil(Identificador As String)


        Conectar()
        Comando = Conexiones.CreateCommand()
        Comando.CommandText = "Select * From dbo.Stencil Where ubicacion='" + Identificador + "'"

        Dim lector As SqlDataReader = Comando.ExecuteReader()

        Dim StencilView As New editstencilform


        If (lector.Read()) Then

            DataGridStencil.StencilNameEdit = lector("Stencil").ToString()
            DataGridStencil.EnsambleEdit = lector("Ensamble").ToString()
            DataGridStencil.NumberPartStencilEdit = lector("PCB").ToString()
            DataGridStencil.XEdit = lector("X").ToString()
            DataGridStencil.YEdit = lector("Y").ToString()
            DataGridStencil.RevisionEdit = lector("Revision").ToString()
            DataGridStencil.JobEdit = lector("JOB").ToString()
            DataGridStencil.LocalidadEdit = lector("Ubicacion").ToString()

            DataGridStencil.Num1TensionEdit = lector("TensionValue1").ToString()
            DataGridStencil.Num2TensionEdit = lector("TensionValue2").ToString()
            DataGridStencil.Num3TensionEdit = lector("TensionValue3").ToString()
            DataGridStencil.Num4TensionEdit = lector("TensionValue4").ToString()
            DataGridStencil.Num5TensionEdit = lector("TensionValue5").ToString()
            DataGridStencil.ComentariosStencilEdit = lector("Comentarios").ToString()

            'LlenarComboProyectos(lector("Id_Proyecto").ToString)
            'proyectName.SelectedValue = Dr("Proyect")
            'DateMakeJob.Norecuerdo = Dr("DateManufacture")
            'DateManufactory.Norecoruedo = Dr("DataRun")
            'provedorNameEdit.Text = Dr("Provedor").ToString()
            'Dim Proyecto = Dr("Proyect").ToString()
        End If


    End Sub

    Function Proyectos()
        'As List(Of ComboBoxProyectos)

        'Conectar()
        Comando = Conexiones.CreateCommand()
        Comando.CommandText = "Select * From dbo.Proyectos"

        Dim lector As SqlDataReader = Comando.ExecuteReader()
        Dim ListaProyectos As New List(Of ComboBoxProyectos)
        Dim ComboBoxProyectos As ComboBoxProyectos


        While (lector.Read())
            'Se va a crear uno nuevo sin repetirse
            ComboBoxProyectos = New ComboBoxProyectos


            If lector.IsDBNull(1) Then
                ComboBoxProyectos.NombreProyect = "Sin nombre"
            Else
                'ComboBoxProyectos.NombreProyecto = lector.GetString(1)
                ComboBoxProyectos.NombreProyect = lector.GetString(1)


            End If
            ListaProyectos.Add(ComboBoxProyectos)
        End While
        'MsgBox(lector.GetString(1))
        'Desconectar()
        Return ListaProyectos
    End Function
    Public Sub prueba()

    End Sub

    Public Sub LlenarComboProyectos()
        'Sub LlenarComboProyectos(IdProyecto As Integer)
        'Conectar()

        Dim Comando As New SqlCommand("Select * From dbo.Proyectos")
        Dim Adapter As New SqlDataAdapter(Comando)
        'Adapter.SelectCommand.CommandType = CommandType.StoredProcedure

        Dim Tabla = New DataSet()

        'Public Datos As DataTable()

        DataGridStencil.TablasProyectos = Tabla
        DataGridStencil.ListProyectos = Adapter.Fill(Table)




        'Comando = Conexiones.CreateCommand()
        'Comando.CommandText = "Select * From dbo.Proyectos"

        'Dim lectorProyectos As SqlDataReader = Comando.ExecuteReader()

        'DataGridStencil.ListProyectos = lectorProyectos.Read()

        'lectorProyectos.GetString()

        'Public ver =lectorProyectos.Read()


        'Dim da As New OleDb.OleDbDataAdapter("Select * From dbo.Proyectos", conexion)
        'Dim ds As New DataSet
        'da.Fill(ds)
        'If ds.Tables(0).Rows.Count > 0 Then
        'ComboBoxProyect.DataSource = ds.Tables(0)
        'ComboBoxProyect.DisplayMember = "Proyecto"
        'ComboBoxProyect.ValueMember = "ID"
        'ComboBoxProyect.SelectedIndex = -1
        '
        ' End If
    End Sub

    Function ConsultaComboBoxProyectos() As List(Of ComboBoxProyectos)
        'Conectar()
        Comando = Conexiones.CreateCommand()

        Comando.CommandText = "Select Proyecto From dbo.Proyectos"
        Dim lectorProyectos As SqlDataReader = Comando.ExecuteReader()

        Dim ListaProyectos As New List(Of ComboBoxProyectos)
        Dim ComboBoxProyectos As ComboBoxProyectos
        While (lectorProyectos.Read())
            ComboBoxProyectos = New ComboBoxProyectos
            '
            'If lectorProyectos.IsDBNull(1) Then
            '    ComboBoxProyectos.NombreProyect = "Vacio"
            'Else
            ComboBoxProyectos.NombreProyect = lectorProyectos.GetString(1)

            'End If
            ListaProyectos.Add(ComboBoxProyectos)
        End While
        'Desconectar()
        MsgBox(lectorProyectos.GetString(1))
        Return ListaProyectos
    End Function


    Function ConsultaStencilDataGridViewer() As List(Of ClassStenciles)
        Conectar()
        Comando = Conexiones.CreateCommand()

        Comando.CommandText = "Select Ubicacion,Stencil,Ensamble,PCB,Comentarios from dbo.Stencil"
        Dim lector As SqlDataReader = Comando.ExecuteReader()

        Dim Lista As New List(Of ClassStenciles)
        Dim ClassStenciles As ClassStenciles
        While (lector.Read())
            'Se va a crear uno nuevo sin repetirse
            ClassStenciles = New ClassStenciles

            If lector.IsDBNull(0) Then
                ClassStenciles.UbicacionSten = "Sin ubicacion"
            Else
                ClassStenciles.UbicacionSten = lector.GetString(0)
            End If


            If lector.IsDBNull(1) Then
                ClassStenciles.NombreSten = "Sin nombre"
            Else
                ClassStenciles.NombreSten = lector.GetString(1)
            End If


            If lector.IsDBNull(2) Then
                ClassStenciles.EnsambleSten = "Sin ensamble"
            Else
                ClassStenciles.EnsambleSten = lector.GetString(2)
            End If

            If lector.IsDBNull(3) Then
                ClassStenciles.PCBSten = "Sin PCB"
            Else
                ClassStenciles.PCBSten = lector.GetString(3)
            End If

            If lector.IsDBNull(4) Then
                ClassStenciles.ComentariosSten = "Sin comentarios"
            Else
                ClassStenciles.ComentariosSten = lector.GetString(4)
            End If

            'MsgBox(lector.GetString(0))
            Lista.Add(ClassStenciles)
        End While
        'MsgBox(ex.ToString)
        Desconectar()
        Return Lista
    End Function





End Class

Public Class Combo1



End Class


