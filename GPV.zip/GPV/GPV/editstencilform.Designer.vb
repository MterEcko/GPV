﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class editstencilform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.PanelF = New System.Windows.Forms.Panel()
        Me.EditStencilBtn = New System.Windows.Forms.Button()
        Me.StencilToolBtn = New System.Windows.Forms.Button()
        Me.Home = New System.Windows.Forms.Button()
        Me.toolingBtn = New System.Windows.Forms.Button()
        Me.PanelFormEditStencil = New System.Windows.Forms.Panel()
        Me.txtEnsambleEdit = New System.Windows.Forms.TextBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.StencilTool1Btn = New System.Windows.Forms.Button()
        Me.edit = New System.Windows.Forms.Label()
        Me.ComboBoxProyectosList = New System.Windows.Forms.ComboBox()
        Me.provedorNameEdit = New System.Windows.Forms.ComboBox()
        Me.txtLocalidadStencilEdit = New System.Windows.Forms.TextBox()
        Me.txtNum1TensionEdit = New System.Windows.Forms.TextBox()
        Me.txtNum5TensionEdit = New System.Windows.Forms.TextBox()
        Me.txtNum2TensionEdit = New System.Windows.Forms.TextBox()
        Me.txtNum4TensionEdit = New System.Windows.Forms.TextBox()
        Me.txtNum3TensionEdit = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtCommentsStencilEdit = New System.Windows.Forms.RichTextBox()
        Me.txtYPCBEdit = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtNumberPartPCBEdit = New System.Windows.Forms.TextBox()
        Me.DateMakeJob = New System.Windows.Forms.DateTimePicker()
        Me.txtJobStencilEdit = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtXPCBEdit = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtRevStencilEdit = New System.Windows.Forms.TextBox()
        Me.DateManufactory = New System.Windows.Forms.DateTimePicker()
        Me.txtStencilNameEdit = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Roperator = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ListView3 = New System.Windows.Forms.ListView()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.PanelF.SuspendLayout()
        Me.PanelFormEditStencil.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelF
        '
        Me.PanelF.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.PanelF.Controls.Add(Me.EditStencilBtn)
        Me.PanelF.Controls.Add(Me.StencilToolBtn)
        Me.PanelF.Controls.Add(Me.Home)
        Me.PanelF.Controls.Add(Me.toolingBtn)
        Me.PanelF.Controls.Add(Me.PanelFormEditStencil)
        Me.PanelF.Controls.Add(Me.ListView3)
        Me.PanelF.Controls.Add(Me.Label21)
        Me.PanelF.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelF.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PanelF.ForeColor = System.Drawing.Color.ForestGreen
        Me.PanelF.Location = New System.Drawing.Point(0, 0)
        Me.PanelF.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelF.Name = "PanelF"
        Me.PanelF.Size = New System.Drawing.Size(683, 574)
        Me.PanelF.TabIndex = 39
        '
        'EditStencilBtn
        '
        Me.EditStencilBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.EditStencilBtn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.EditStencilBtn.FlatAppearance.BorderSize = 3
        Me.EditStencilBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.EditStencilBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.EditStencilBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.EditStencilBtn.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.EditStencilBtn.ForeColor = System.Drawing.Color.ForestGreen
        Me.EditStencilBtn.Location = New System.Drawing.Point(340, 12)
        Me.EditStencilBtn.Name = "EditStencilBtn"
        Me.EditStencilBtn.Size = New System.Drawing.Size(122, 38)
        Me.EditStencilBtn.TabIndex = 124
        Me.EditStencilBtn.Text = "Edit Stencil"
        Me.EditStencilBtn.UseVisualStyleBackColor = False
        '
        'StencilToolBtn
        '
        Me.StencilToolBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.StencilToolBtn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.StencilToolBtn.FlatAppearance.BorderSize = 3
        Me.StencilToolBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.StencilToolBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.StencilToolBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.StencilToolBtn.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.StencilToolBtn.ForeColor = System.Drawing.Color.ForestGreen
        Me.StencilToolBtn.Location = New System.Drawing.Point(231, 12)
        Me.StencilToolBtn.Name = "StencilToolBtn"
        Me.StencilToolBtn.Size = New System.Drawing.Size(103, 38)
        Me.StencilToolBtn.TabIndex = 123
        Me.StencilToolBtn.Text = "Stencils"
        Me.StencilToolBtn.UseVisualStyleBackColor = False
        '
        'Home
        '
        Me.Home.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.Home.FlatAppearance.BorderSize = 3
        Me.Home.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Home.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.Home.ForeColor = System.Drawing.Color.ForestGreen
        Me.Home.Location = New System.Drawing.Point(13, 12)
        Me.Home.Name = "Home"
        Me.Home.Size = New System.Drawing.Size(103, 38)
        Me.Home.TabIndex = 122
        Me.Home.Text = "Home"
        Me.Home.UseVisualStyleBackColor = False
        '
        'toolingBtn
        '
        Me.toolingBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.toolingBtn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.toolingBtn.FlatAppearance.BorderSize = 3
        Me.toolingBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.toolingBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.toolingBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.toolingBtn.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.toolingBtn.ForeColor = System.Drawing.Color.ForestGreen
        Me.toolingBtn.Location = New System.Drawing.Point(122, 12)
        Me.toolingBtn.Name = "toolingBtn"
        Me.toolingBtn.Size = New System.Drawing.Size(103, 38)
        Me.toolingBtn.TabIndex = 121
        Me.toolingBtn.Text = "Tooling"
        Me.toolingBtn.UseVisualStyleBackColor = False
        '
        'PanelFormEditStencil
        '
        Me.PanelFormEditStencil.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelFormEditStencil.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PanelFormEditStencil.Controls.Add(Me.ListBox1)
        Me.PanelFormEditStencil.Controls.Add(Me.txtEnsambleEdit)
        Me.PanelFormEditStencil.Controls.Add(Me.Panel3)
        Me.PanelFormEditStencil.Controls.Add(Me.ComboBoxProyectosList)
        Me.PanelFormEditStencil.Controls.Add(Me.provedorNameEdit)
        Me.PanelFormEditStencil.Controls.Add(Me.txtLocalidadStencilEdit)
        Me.PanelFormEditStencil.Controls.Add(Me.txtNum1TensionEdit)
        Me.PanelFormEditStencil.Controls.Add(Me.txtNum5TensionEdit)
        Me.PanelFormEditStencil.Controls.Add(Me.txtNum2TensionEdit)
        Me.PanelFormEditStencil.Controls.Add(Me.txtNum4TensionEdit)
        Me.PanelFormEditStencil.Controls.Add(Me.txtNum3TensionEdit)
        Me.PanelFormEditStencil.Controls.Add(Me.Label22)
        Me.PanelFormEditStencil.Controls.Add(Me.txtCommentsStencilEdit)
        Me.PanelFormEditStencil.Controls.Add(Me.txtYPCBEdit)
        Me.PanelFormEditStencil.Controls.Add(Me.Label14)
        Me.PanelFormEditStencil.Controls.Add(Me.txtNumberPartPCBEdit)
        Me.PanelFormEditStencil.Controls.Add(Me.DateMakeJob)
        Me.PanelFormEditStencil.Controls.Add(Me.txtJobStencilEdit)
        Me.PanelFormEditStencil.Controls.Add(Me.Label10)
        Me.PanelFormEditStencil.Controls.Add(Me.Label7)
        Me.PanelFormEditStencil.Controls.Add(Me.Label9)
        Me.PanelFormEditStencil.Controls.Add(Me.txtXPCBEdit)
        Me.PanelFormEditStencil.Controls.Add(Me.Label8)
        Me.PanelFormEditStencil.Controls.Add(Me.txtRevStencilEdit)
        Me.PanelFormEditStencil.Controls.Add(Me.DateManufactory)
        Me.PanelFormEditStencil.Controls.Add(Me.txtStencilNameEdit)
        Me.PanelFormEditStencil.Controls.Add(Me.PictureBox1)
        Me.PanelFormEditStencil.Controls.Add(Me.Panel4)
        Me.PanelFormEditStencil.Location = New System.Drawing.Point(5, 58)
        Me.PanelFormEditStencil.Margin = New System.Windows.Forms.Padding(20)
        Me.PanelFormEditStencil.Name = "PanelFormEditStencil"
        Me.PanelFormEditStencil.Size = New System.Drawing.Size(673, 504)
        Me.PanelFormEditStencil.TabIndex = 103
        '
        'txtEnsambleEdit
        '
        Me.txtEnsambleEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtEnsambleEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtEnsambleEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtEnsambleEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEnsambleEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtEnsambleEdit.Location = New System.Drawing.Point(140, 92)
        Me.txtEnsambleEdit.Margin = New System.Windows.Forms.Padding(5)
        Me.txtEnsambleEdit.MaximumSize = New System.Drawing.Size(192, 40)
        Me.txtEnsambleEdit.MaxLength = 50
        Me.txtEnsambleEdit.MinimumSize = New System.Drawing.Size(133, 15)
        Me.txtEnsambleEdit.Name = "txtEnsambleEdit"
        Me.txtEnsambleEdit.Size = New System.Drawing.Size(192, 20)
        Me.txtEnsambleEdit.TabIndex = 138
        Me.txtEnsambleEdit.Text = "Number Part of Ensamble"
        '
        'Panel3
        '
        Me.Panel3.AutoSize = True
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Panel3.Controls.Add(Me.StencilTool1Btn)
        Me.Panel3.Controls.Add(Me.edit)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(10, 3, 10, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(671, 47)
        Me.Panel3.TabIndex = 137
        '
        'StencilTool1Btn
        '
        Me.StencilTool1Btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.StencilTool1Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.StencilTool1Btn.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.StencilTool1Btn.FlatAppearance.BorderSize = 3
        Me.StencilTool1Btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.StencilTool1Btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.StencilTool1Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.StencilTool1Btn.Font = New System.Drawing.Font("Tahoma", 14.0!)
        Me.StencilTool1Btn.ForeColor = System.Drawing.Color.ForestGreen
        Me.StencilTool1Btn.Location = New System.Drawing.Point(511, 6)
        Me.StencilTool1Btn.Name = "StencilTool1Btn"
        Me.StencilTool1Btn.Size = New System.Drawing.Size(156, 38)
        Me.StencilTool1Btn.TabIndex = 111
        Me.StencilTool1Btn.Text = "Stencils"
        Me.StencilTool1Btn.UseVisualStyleBackColor = False
        '
        'edit
        '
        Me.edit.AutoSize = True
        Me.edit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.edit.ForeColor = System.Drawing.Color.White
        Me.edit.Location = New System.Drawing.Point(31, 14)
        Me.edit.Name = "edit"
        Me.edit.Size = New System.Drawing.Size(87, 19)
        Me.edit.TabIndex = 109
        Me.edit.Text = "Edit Stencil"
        '
        'ComboBoxProyectosList
        '
        Me.ComboBoxProyectosList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBoxProyectosList.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.ComboBoxProyectosList.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ComboBoxProyectosList.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.ComboBoxProyectosList.ForeColor = System.Drawing.Color.ForestGreen
        Me.ComboBoxProyectosList.FormattingEnabled = True
        Me.ComboBoxProyectosList.Items.AddRange(New Object() {"Provedor", "Prueba"})
        Me.ComboBoxProyectosList.Location = New System.Drawing.Point(140, 146)
        Me.ComboBoxProyectosList.Margin = New System.Windows.Forms.Padding(0)
        Me.ComboBoxProyectosList.MaximumSize = New System.Drawing.Size(230, 0)
        Me.ComboBoxProyectosList.Name = "ComboBoxProyectosList"
        Me.ComboBoxProyectosList.Size = New System.Drawing.Size(230, 27)
        Me.ComboBoxProyectosList.TabIndex = 136
        Me.ComboBoxProyectosList.Tag = "Proyecto"
        Me.ComboBoxProyectosList.Text = "Proyecto"
        '
        'provedorNameEdit
        '
        Me.provedorNameEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.provedorNameEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.provedorNameEdit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.provedorNameEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.provedorNameEdit.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.provedorNameEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.provedorNameEdit.FormattingEnabled = True
        Me.provedorNameEdit.Items.AddRange(New Object() {"Provedor", "Prueba"})
        Me.provedorNameEdit.Location = New System.Drawing.Point(140, 280)
        Me.provedorNameEdit.Margin = New System.Windows.Forms.Padding(0)
        Me.provedorNameEdit.MaximumSize = New System.Drawing.Size(155, 0)
        Me.provedorNameEdit.Name = "provedorNameEdit"
        Me.provedorNameEdit.Size = New System.Drawing.Size(154, 27)
        Me.provedorNameEdit.TabIndex = 134
        '
        'txtLocalidadStencilEdit
        '
        Me.txtLocalidadStencilEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtLocalidadStencilEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtLocalidadStencilEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtLocalidadStencilEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLocalidadStencilEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtLocalidadStencilEdit.Location = New System.Drawing.Point(139, 368)
        Me.txtLocalidadStencilEdit.Margin = New System.Windows.Forms.Padding(5)
        Me.txtLocalidadStencilEdit.MaximumSize = New System.Drawing.Size(192, 40)
        Me.txtLocalidadStencilEdit.MaxLength = 50
        Me.txtLocalidadStencilEdit.MinimumSize = New System.Drawing.Size(133, 15)
        Me.txtLocalidadStencilEdit.Name = "txtLocalidadStencilEdit"
        Me.txtLocalidadStencilEdit.Size = New System.Drawing.Size(133, 20)
        Me.txtLocalidadStencilEdit.TabIndex = 133
        Me.txtLocalidadStencilEdit.Text = "Localidad"
        '
        'txtNum1TensionEdit
        '
        Me.txtNum1TensionEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNum1TensionEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.txtNum1TensionEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtNum1TensionEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNum1TensionEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtNum1TensionEdit.Location = New System.Drawing.Point(412, 103)
        Me.txtNum1TensionEdit.Margin = New System.Windows.Forms.Padding(5)
        Me.txtNum1TensionEdit.MaximumSize = New System.Drawing.Size(73, 20)
        Me.txtNum1TensionEdit.MinimumSize = New System.Drawing.Size(27, 20)
        Me.txtNum1TensionEdit.Name = "txtNum1TensionEdit"
        Me.txtNum1TensionEdit.Size = New System.Drawing.Size(73, 20)
        Me.txtNum1TensionEdit.TabIndex = 103
        Me.txtNum1TensionEdit.Text = "Value"
        '
        'txtNum5TensionEdit
        '
        Me.txtNum5TensionEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNum5TensionEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.txtNum5TensionEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtNum5TensionEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNum5TensionEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtNum5TensionEdit.Location = New System.Drawing.Point(478, 170)
        Me.txtNum5TensionEdit.Margin = New System.Windows.Forms.Padding(5)
        Me.txtNum5TensionEdit.MaximumSize = New System.Drawing.Size(73, 20)
        Me.txtNum5TensionEdit.MinimumSize = New System.Drawing.Size(67, 20)
        Me.txtNum5TensionEdit.Name = "txtNum5TensionEdit"
        Me.txtNum5TensionEdit.Size = New System.Drawing.Size(73, 20)
        Me.txtNum5TensionEdit.TabIndex = 126
        Me.txtNum5TensionEdit.Text = "Value 5"
        '
        'txtNum2TensionEdit
        '
        Me.txtNum2TensionEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNum2TensionEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.txtNum2TensionEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtNum2TensionEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNum2TensionEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtNum2TensionEdit.Location = New System.Drawing.Point(538, 103)
        Me.txtNum2TensionEdit.Margin = New System.Windows.Forms.Padding(5)
        Me.txtNum2TensionEdit.MaximumSize = New System.Drawing.Size(73, 20)
        Me.txtNum2TensionEdit.MinimumSize = New System.Drawing.Size(27, 20)
        Me.txtNum2TensionEdit.Name = "txtNum2TensionEdit"
        Me.txtNum2TensionEdit.Size = New System.Drawing.Size(73, 20)
        Me.txtNum2TensionEdit.TabIndex = 104
        Me.txtNum2TensionEdit.Text = "Value 2"
        '
        'txtNum4TensionEdit
        '
        Me.txtNum4TensionEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNum4TensionEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.txtNum4TensionEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtNum4TensionEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNum4TensionEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtNum4TensionEdit.Location = New System.Drawing.Point(538, 240)
        Me.txtNum4TensionEdit.Margin = New System.Windows.Forms.Padding(5)
        Me.txtNum4TensionEdit.MaximumSize = New System.Drawing.Size(73, 20)
        Me.txtNum4TensionEdit.MinimumSize = New System.Drawing.Size(27, 20)
        Me.txtNum4TensionEdit.Name = "txtNum4TensionEdit"
        Me.txtNum4TensionEdit.Size = New System.Drawing.Size(73, 20)
        Me.txtNum4TensionEdit.TabIndex = 105
        Me.txtNum4TensionEdit.Text = "Value 4"
        '
        'txtNum3TensionEdit
        '
        Me.txtNum3TensionEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNum3TensionEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.txtNum3TensionEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtNum3TensionEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNum3TensionEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtNum3TensionEdit.Location = New System.Drawing.Point(412, 240)
        Me.txtNum3TensionEdit.Margin = New System.Windows.Forms.Padding(5)
        Me.txtNum3TensionEdit.MaximumSize = New System.Drawing.Size(73, 20)
        Me.txtNum3TensionEdit.MinimumSize = New System.Drawing.Size(27, 20)
        Me.txtNum3TensionEdit.Name = "txtNum3TensionEdit"
        Me.txtNum3TensionEdit.Size = New System.Drawing.Size(73, 20)
        Me.txtNum3TensionEdit.TabIndex = 106
        Me.txtNum3TensionEdit.Text = "Value 3"
        '
        'Label22
        '
        Me.Label22.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(387, 291)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(113, 23)
        Me.Label22.TabIndex = 123
        Me.Label22.Text = "Comentarios"
        '
        'txtCommentsStencilEdit
        '
        Me.txtCommentsStencilEdit.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtCommentsStencilEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtCommentsStencilEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCommentsStencilEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtCommentsStencilEdit.Location = New System.Drawing.Point(391, 314)
        Me.txtCommentsStencilEdit.Margin = New System.Windows.Forms.Padding(0)
        Me.txtCommentsStencilEdit.MaximumSize = New System.Drawing.Size(467, 172)
        Me.txtCommentsStencilEdit.MinimumSize = New System.Drawing.Size(213, 86)
        Me.txtCommentsStencilEdit.Name = "txtCommentsStencilEdit"
        Me.txtCommentsStencilEdit.Size = New System.Drawing.Size(248, 86)
        Me.txtCommentsStencilEdit.TabIndex = 124
        Me.txtCommentsStencilEdit.Text = "Ingrese comentarios"
        '
        'txtYPCBEdit
        '
        Me.txtYPCBEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtYPCBEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtYPCBEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtYPCBEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtYPCBEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtYPCBEdit.Location = New System.Drawing.Point(237, 248)
        Me.txtYPCBEdit.Margin = New System.Windows.Forms.Padding(5)
        Me.txtYPCBEdit.MaximumSize = New System.Drawing.Size(93, 40)
        Me.txtYPCBEdit.MaxLength = 30
        Me.txtYPCBEdit.MinimumSize = New System.Drawing.Size(40, 15)
        Me.txtYPCBEdit.Name = "txtYPCBEdit"
        Me.txtYPCBEdit.Size = New System.Drawing.Size(58, 20)
        Me.txtYPCBEdit.TabIndex = 125
        Me.txtYPCBEdit.Text = "Y Width"
        '
        'Label14
        '
        Me.Label14.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(400, 58)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.MaximumSize = New System.Drawing.Size(181, 31)
        Me.Label14.MinimumSize = New System.Drawing.Size(181, 31)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(181, 31)
        Me.Label14.TabIndex = 117
        Me.Label14.Text = "Tension inicial"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtNumberPartPCBEdit
        '
        Me.txtNumberPartPCBEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNumberPartPCBEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtNumberPartPCBEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtNumberPartPCBEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNumberPartPCBEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtNumberPartPCBEdit.Location = New System.Drawing.Point(140, 118)
        Me.txtNumberPartPCBEdit.Margin = New System.Windows.Forms.Padding(5)
        Me.txtNumberPartPCBEdit.MaximumSize = New System.Drawing.Size(192, 40)
        Me.txtNumberPartPCBEdit.MaxLength = 50
        Me.txtNumberPartPCBEdit.MinimumSize = New System.Drawing.Size(133, 15)
        Me.txtNumberPartPCBEdit.Name = "txtNumberPartPCBEdit"
        Me.txtNumberPartPCBEdit.Size = New System.Drawing.Size(155, 20)
        Me.txtNumberPartPCBEdit.TabIndex = 108
        Me.txtNumberPartPCBEdit.Text = "Number Part of PCB"
        '
        'DateMakeJob
        '
        Me.DateMakeJob.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DateMakeJob.CalendarForeColor = System.Drawing.Color.ForestGreen
        Me.DateMakeJob.CalendarMonthBackground = System.Drawing.Color.ForestGreen
        Me.DateMakeJob.CalendarTitleBackColor = System.Drawing.Color.ForestGreen
        Me.DateMakeJob.CalendarTitleForeColor = System.Drawing.Color.ForestGreen
        Me.DateMakeJob.CalendarTrailingForeColor = System.Drawing.Color.ForestGreen
        Me.DateMakeJob.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateMakeJob.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateMakeJob.Location = New System.Drawing.Point(140, 180)
        Me.DateMakeJob.Margin = New System.Windows.Forms.Padding(4)
        Me.DateMakeJob.MaxDate = New Date(2099, 12, 31, 0, 0, 0, 0)
        Me.DateMakeJob.MaximumSize = New System.Drawing.Size(155, 27)
        Me.DateMakeJob.MinDate = New Date(2010, 1, 1, 0, 0, 0, 0)
        Me.DateMakeJob.MinimumSize = New System.Drawing.Size(132, 4)
        Me.DateMakeJob.Name = "DateMakeJob"
        Me.DateMakeJob.Size = New System.Drawing.Size(155, 27)
        Me.DateMakeJob.TabIndex = 112
        '
        'txtJobStencilEdit
        '
        Me.txtJobStencilEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtJobStencilEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtJobStencilEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtJobStencilEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtJobStencilEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtJobStencilEdit.Location = New System.Drawing.Point(140, 341)
        Me.txtJobStencilEdit.Margin = New System.Windows.Forms.Padding(5)
        Me.txtJobStencilEdit.MaximumSize = New System.Drawing.Size(192, 40)
        Me.txtJobStencilEdit.MaxLength = 30
        Me.txtJobStencilEdit.MinimumSize = New System.Drawing.Size(133, 15)
        Me.txtJobStencilEdit.Name = "txtJobStencilEdit"
        Me.txtJobStencilEdit.Size = New System.Drawing.Size(192, 20)
        Me.txtJobStencilEdit.TabIndex = 122
        Me.txtJobStencilEdit.Text = "Job"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(7, 184)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(130, 19)
        Me.Label10.TabIndex = 113
        Me.Label10.Text = "Fecha fabricacion"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(7, 216)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(128, 19)
        Me.Label7.TabIndex = 109
        Me.Label7.Text = "Fecha de ingreso"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(58, 283)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(73, 19)
        Me.Label9.TabIndex = 111
        Me.Label9.Text = "Provedor"
        '
        'txtXPCBEdit
        '
        Me.txtXPCBEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtXPCBEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtXPCBEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtXPCBEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtXPCBEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtXPCBEdit.Location = New System.Drawing.Point(140, 248)
        Me.txtXPCBEdit.Margin = New System.Windows.Forms.Padding(5)
        Me.txtXPCBEdit.MaximumSize = New System.Drawing.Size(93, 40)
        Me.txtXPCBEdit.MaxLength = 30
        Me.txtXPCBEdit.MinimumSize = New System.Drawing.Size(40, 15)
        Me.txtXPCBEdit.Name = "txtXPCBEdit"
        Me.txtXPCBEdit.Size = New System.Drawing.Size(88, 20)
        Me.txtXPCBEdit.TabIndex = 115
        Me.txtXPCBEdit.Text = "X Lengh"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(65, 249)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(66, 19)
        Me.Label8.TabIndex = 110
        Me.Label8.Text = "Medidas"
        '
        'txtRevStencilEdit
        '
        Me.txtRevStencilEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtRevStencilEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtRevStencilEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtRevStencilEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRevStencilEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtRevStencilEdit.Location = New System.Drawing.Point(140, 314)
        Me.txtRevStencilEdit.Margin = New System.Windows.Forms.Padding(5)
        Me.txtRevStencilEdit.MaximumSize = New System.Drawing.Size(192, 40)
        Me.txtRevStencilEdit.MaxLength = 30
        Me.txtRevStencilEdit.MinimumSize = New System.Drawing.Size(155, 15)
        Me.txtRevStencilEdit.Name = "txtRevStencilEdit"
        Me.txtRevStencilEdit.Size = New System.Drawing.Size(155, 20)
        Me.txtRevStencilEdit.TabIndex = 119
        Me.txtRevStencilEdit.Text = "Revision"
        '
        'DateManufactory
        '
        Me.DateManufactory.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DateManufactory.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.DateManufactory.CalendarTitleForeColor = System.Drawing.Color.ForestGreen
        Me.DateManufactory.CalendarTrailingForeColor = System.Drawing.Color.ForestGreen
        Me.DateManufactory.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateManufactory.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateManufactory.Location = New System.Drawing.Point(140, 214)
        Me.DateManufactory.Margin = New System.Windows.Forms.Padding(4)
        Me.DateManufactory.MaximumSize = New System.Drawing.Size(155, 27)
        Me.DateManufactory.MinimumSize = New System.Drawing.Size(132, 4)
        Me.DateManufactory.Name = "DateManufactory"
        Me.DateManufactory.Size = New System.Drawing.Size(155, 27)
        Me.DateManufactory.TabIndex = 114
        '
        'txtStencilNameEdit
        '
        Me.txtStencilNameEdit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtStencilNameEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.txtStencilNameEdit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtStencilNameEdit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStencilNameEdit.ForeColor = System.Drawing.Color.ForestGreen
        Me.txtStencilNameEdit.Location = New System.Drawing.Point(140, 65)
        Me.txtStencilNameEdit.Margin = New System.Windows.Forms.Padding(0, 0, 0, 6)
        Me.txtStencilNameEdit.MaximumSize = New System.Drawing.Size(192, 40)
        Me.txtStencilNameEdit.MaxLength = 50
        Me.txtStencilNameEdit.MinimumSize = New System.Drawing.Size(133, 15)
        Me.txtStencilNameEdit.Name = "txtStencilNameEdit"
        Me.txtStencilNameEdit.Size = New System.Drawing.Size(155, 20)
        Me.txtStencilNameEdit.TabIndex = 107
        Me.txtStencilNameEdit.Text = "Stencil Name"
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.Image = Global.GPV.My.Resources.Resources.frame_stencil_tension
        Me.PictureBox1.Location = New System.Drawing.Point(378, 92)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox1.MaximumSize = New System.Drawing.Size(520, 290)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(269, 185)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 118
        Me.PictureBox1.TabStop = False
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Roperator)
        Me.Panel4.Controls.Add(Me.Button1)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel4.Location = New System.Drawing.Point(0, 416)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(671, 86)
        Me.Panel4.TabIndex = 102
        '
        'Roperator
        '
        Me.Roperator.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Roperator.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Roperator.FlatAppearance.BorderSize = 0
        Me.Roperator.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.Roperator.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.Roperator.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Roperator.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Roperator.ForeColor = System.Drawing.Color.White
        Me.Roperator.Location = New System.Drawing.Point(71, 12)
        Me.Roperator.Margin = New System.Windows.Forms.Padding(5)
        Me.Roperator.Name = "Roperator"
        Me.Roperator.Size = New System.Drawing.Size(297, 58)
        Me.Roperator.TabIndex = 62
        Me.Roperator.Text = "SAVE"
        Me.Roperator.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(147, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(81, Byte), Integer), CType(CType(135, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.Button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(337, 12)
        Me.Button1.Margin = New System.Windows.Forms.Padding(5)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(240, 58)
        Me.Button1.TabIndex = 98
        Me.Button1.Text = "Return"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'ListView3
        '
        Me.ListView3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListView3.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(67, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.ListView3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListView3.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListView3.HideSelection = False
        Me.ListView3.Location = New System.Drawing.Point(182, 441)
        Me.ListView3.Margin = New System.Windows.Forms.Padding(4)
        Me.ListView3.MaximumSize = New System.Drawing.Size(173, 23)
        Me.ListView3.MinimumSize = New System.Drawing.Size(133, 23)
        Me.ListView3.Name = "ListView3"
        Me.ListView3.Size = New System.Drawing.Size(145, 23)
        Me.ListView3.TabIndex = 95
        Me.ListView3.UseCompatibleStateImageBehavior = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(103, 441)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(75, 19)
        Me.Label21.TabIndex = 93
        Me.Label21.Text = "Localidad"
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 19
        Me.ListBox1.Location = New System.Drawing.Point(35, 146)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(184, 23)
        Me.ListBox1.TabIndex = 139
        '
        'editstencilform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(683, 574)
        Me.Controls.Add(Me.PanelF)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.ForestGreen
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "editstencilform"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "editstencil"
        Me.PanelF.ResumeLayout(False)
        Me.PanelF.PerformLayout()
        Me.PanelFormEditStencil.ResumeLayout(False)
        Me.PanelFormEditStencil.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelF As System.Windows.Forms.Panel
    Friend WithEvents ListView3 As System.Windows.Forms.ListView
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents PanelFormEditStencil As System.Windows.Forms.Panel
    Friend WithEvents txtNum1TensionEdit As System.Windows.Forms.TextBox
    Friend WithEvents txtNum5TensionEdit As System.Windows.Forms.TextBox
    Friend WithEvents txtNum2TensionEdit As System.Windows.Forms.TextBox
    Friend WithEvents txtNum4TensionEdit As System.Windows.Forms.TextBox
    Friend WithEvents txtNum3TensionEdit As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtCommentsStencilEdit As System.Windows.Forms.RichTextBox
    Friend WithEvents txtYPCBEdit As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents DateMakeJob As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtJobStencilEdit As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtXPCBEdit As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtRevStencilEdit As System.Windows.Forms.TextBox
    Friend WithEvents DateManufactory As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtStencilNameEdit As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Roperator As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents txtLocalidadStencilEdit As System.Windows.Forms.TextBox
    Friend WithEvents provedorNameEdit As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxProyectosList As System.Windows.Forms.ComboBox
    Friend WithEvents EditStencilBtn As System.Windows.Forms.Button
    Friend WithEvents StencilToolBtn As System.Windows.Forms.Button
    Friend WithEvents Home As System.Windows.Forms.Button
    Friend WithEvents toolingBtn As System.Windows.Forms.Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents StencilTool1Btn As System.Windows.Forms.Button
    Friend WithEvents edit As System.Windows.Forms.Label
    Friend WithEvents txtNumberPartPCBEdit As TextBox
    Friend WithEvents txtEnsambleEdit As TextBox
    Friend WithEvents ListBox1 As ListBox
End Class
