﻿Public Class Tooling
    Private Sub hideStencil()
        PanelF.Visible = False
    End Sub
    Private Sub showStencil()

    End Sub
    Private PFormu As Form = Nothing
    Private Sub openPanel(PanelForm As Form)
        If PFormu IsNot Nothing Then PFormu.Close()
        PFormu = PanelForm
        PanelForm.TopLevel = False
        PanelForm.FormBorderStyle = FormBorderStyle.None
        PanelForm.Dock = DockStyle.Fill
        PanelF.Controls.Add(PanelForm)
        PanelF.Tag = PanelForm
        PanelForm.BringToFront()
        PanelForm.Show()
    End Sub

    Private Sub Home_Click(sender As Object, e As EventArgs) Handles Home.Click, Home1Btn.Click
        openPanel(New dashboardPanel)
    End Sub

    Private Sub StencilBtn_Click(sender As Object, e As EventArgs) Handles StencilBtn.Click
        openPanel(New Stencil)
    End Sub

    Private Sub routerDishBtn_Click(sender As Object, e As EventArgs) Handles routerDishBtn.Click
        openPanel(New routerdish)
    End Sub

    Private Sub PalletsSelectiveBtn_Click(sender As Object, e As EventArgs) Handles PalletsSelectiveBtn.Click
        openPanel(New pallet)
    End Sub
End Class