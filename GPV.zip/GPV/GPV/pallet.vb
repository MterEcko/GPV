﻿Public Class pallet
    Private Sub hideForm()
        PanelF.Visible = False
    End Sub
    Private Sub showForm()

    End Sub
    Private PFormu As Form = Nothing
    Private Sub openPanel(PanelForm As Form)
        If PFormu IsNot Nothing Then PFormu.Close()
        PFormu = PanelForm
        PanelForm.TopLevel = False
        PanelForm.FormBorderStyle = FormBorderStyle.None
        PanelForm.Dock = DockStyle.Fill
        PanelF.Controls.Add(PanelForm)
        PanelF.Tag = PanelForm
        PanelForm.BringToFront()
        PanelForm.Show()
    End Sub

    Private Sub Home_Click(sender As Object, e As EventArgs) Handles Home.Click
        openPanel(New dashboardPanel)
    End Sub

    Private Sub ToolingBtn_Click(sender As Object, e As EventArgs) Handles toolingBtn.Click, Tooling1Btn.Click
        openPanel(New Tooling)
    End Sub

    Private Sub PalletsToolBtn_Click(sender As Object, e As EventArgs) Handles PalletsToolBtn.Click
        openPanel(New pallet)
    End Sub

    Private Sub addPalletBtnForm_Click(sender As Object, e As EventArgs) Handles addPalletBtnForm.Click
        openPanel(New addpalletform)
    End Sub

    Private Sub editPalletBtnForm_Click(sender As Object, e As EventArgs) Handles editPalletBtnForm.Click
        openPanel(New editpalletform)
    End Sub

    Private Sub viewLogPalletBtn_Click(sender As Object, e As EventArgs) Handles viewLogPalletBtn.Click
        openPanel(New logpalletform)
    End Sub
End Class